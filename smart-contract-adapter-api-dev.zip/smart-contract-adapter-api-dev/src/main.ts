/* eslint-disable @typescript-eslint/naming-convention */
import { Logger, ValidationPipe } from '@nestjs/common'
import { ConfigService } from '@nestjs/config'
import { NestFactory } from '@nestjs/core'

import { AppModule } from './app.module'
import { AllExceptionsFilter } from './all-exceptions.filter'
import { EnvironmentKeysEnum } from './config/config'

const logger = new Logger('AppBootstrap')

const DEFAULT_APP_HORT = 'localhost'
const DEFAULT_APP_PORT = 3000

async function bootstrap(): Promise<void> {
    const app = await NestFactory.create(AppModule)

    const configService = app.get(ConfigService)

    const port = configService.get(EnvironmentKeysEnum.PORT) || DEFAULT_APP_PORT
    const hostname = configService.get(EnvironmentKeysEnum.HOST) || DEFAULT_APP_HORT

    app.useGlobalPipes(
        new ValidationPipe({
            transform: true,
            disableErrorMessages: false,
        }),
    )
    app.useGlobalFilters(new AllExceptionsFilter())

    await app.listen(port, hostname, () =>
        logger.log(`Server running at ${hostname}:${port}`),
    )
}

// eslint-disable-next-line @typescript-eslint/no-extra-semi
;(async (): Promise<void> => {
    await bootstrap()
})().catch((error) => {
    logger.error(`Main error: ${error.message}`)
    throw error
})
