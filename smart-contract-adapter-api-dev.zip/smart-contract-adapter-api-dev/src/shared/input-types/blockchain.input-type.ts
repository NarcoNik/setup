import { Field, InputType } from '@nestjs/graphql'
import { BlockchainEnum } from '@defi-invest/common'

@InputType()
export class BlockchainInputType {
    @Field(() => BlockchainEnum)
    blockchain: BlockchainEnum
}
