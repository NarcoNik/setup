export type ExceptionType = {
    readonly stack?: string
    getResponse(): string | object
}