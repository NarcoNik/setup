import { BlockchainEnum } from '@defi-invest/common'
import BigNumber from 'bignumber.js'

const NATIVE_ADDRESSES = {
    [BlockchainEnum.ETH]: '0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2',
    [BlockchainEnum.BNB]: '0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c',
}

export const checkNativeCurrency = (
    blockchain: BlockchainEnum,
    tokenAddress: string,
): boolean => {
    const nativeAddress = NATIVE_ADDRESSES[blockchain]
    return nativeAddress === tokenAddress.toLowerCase()
}

export function sumCurrencies(a: BigNumber.Value): BigNumber
export function sumCurrencies(a: BigNumber.Value, b: BigNumber.Value): BigNumber
export function sumCurrencies(a: BigNumber.Value, b?: BigNumber.Value): BigNumber {
    if (!b) {
        return new BigNumber(a)
    }
    return new BigNumber(a).plus(b)
}
