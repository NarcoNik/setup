import { createUnionType, Field, ObjectType } from '@nestjs/graphql'
import { ResponseErrorType } from '@defi-invest/common'

@ObjectType()
class BooleanValue {
    @Field(() => Boolean)
    result: boolean
}

export const BooleanObjectUnionType = createUnionType({
    name: 'BooleanObjectUnionType',
    types: () => [BooleanValue, ResponseErrorType] as const,
    resolveType(value) {
        if (value.code) {
            return 'ResponseErrorType'
        }
        return 'BooleanValue'
    },
})
