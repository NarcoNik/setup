import { TokenObjectType } from './token.object-type'
import { Field, ObjectType } from '@nestjs/graphql'

@ObjectType()
export class TokenMinObjectType extends TokenObjectType {
    @Field(() => String)
    tokenMinAmount: string
}