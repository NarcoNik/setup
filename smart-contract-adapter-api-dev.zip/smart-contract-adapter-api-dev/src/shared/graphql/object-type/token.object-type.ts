import { Field, ObjectType } from '@nestjs/graphql'

@ObjectType()
export class TokenObjectType {
    @Field(() => String, { description: `Token Address` })
    tokenAddress: string

    @Field(() => String, { description: `Token Amount` })
    tokenAmount: string
}