import { Field, ObjectType } from '@nestjs/graphql'
@ObjectType()
export class TokensRatioObjectType {
    @Field(() => String)
    tokenAddress: string

    @Field(() => String)
    percent: string
}
@ObjectType()
export class PoolTokensRatioObjectType {
    @Field(() => [TokensRatioObjectType])
    tokensRatio: TokensRatioObjectType[]
}

