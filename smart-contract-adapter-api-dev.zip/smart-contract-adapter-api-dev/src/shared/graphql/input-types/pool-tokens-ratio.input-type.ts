import { Field, InputType } from '@nestjs/graphql'

@InputType()
export class TokensRatioInputType {
    @Field(() => String)
    tokenAddress: string

    @Field(() => String)
    percent: string
}

@InputType()
export class PoolTokensRatioInputType {
    @Field(() => [TokensRatioInputType])
    tokensRatio: TokensRatioInputType[]
}

@InputType()
export class PoolWithTokenRatioInput {
    @Field(() => String)
    poolAddress: string

    @Field(() => String)
    poolWeightInPercent: string //  "25.252525"

    @Field(() => [TokensRatioInputType])
    tokensRatio: TokensRatioInputType[]
}
