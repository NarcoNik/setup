import { Field, InputType } from '@nestjs/graphql'

@InputType()
export class TokenInputType {
    @Field(() => String, { description: `Token Address` })
    tokenAddress: string

    @Field(() => String, { description: `Token Amount` })
    tokenAmount: string
}