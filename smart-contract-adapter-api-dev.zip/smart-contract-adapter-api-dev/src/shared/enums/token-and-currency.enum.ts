export enum TokenAndCurrencyEnum {
    ETH = 'ETH',
    WETH = 'WETH',
    BNB = 'BNB',
    WBNB = 'WBNB',
}
