import { Module } from '@nestjs/common'
import { ConfigModule } from '@nestjs/config'
import { CryptoApiService } from './crypto-api.service'
import { GraphQlClientModule } from '@defi-invest/common'
import { EnvironmentKeysEnum } from '../../config/config'

@Module({
    imports: [
        ConfigModule,
        GraphQlClientModule.register({
            urlEnvName: EnvironmentKeysEnum.SMART_CONTRACT_CRYPTO_API,
        }),
    ],
    providers: [CryptoApiService],
    exports: [CryptoApiService],
})
export class CryptoApiModule {}
