/* eslint-disable @typescript-eslint/naming-convention */
import { InjectGraphQlClient } from '@defi-invest/common'
import { BadRequestException, Injectable } from '@nestjs/common'
import { GraphQlClientService } from '@defi-invest/common'
import {
    everything,
    generateMutationOp,
    generateQueryOp,
    Mutation, Query,
    SendTransactionInputType, UnsignedTransactionObjectType,
} from '@genql/smart-contract-crypto-api'
import { EnvironmentKeysEnum } from '../../config/config'

@Injectable()
export class CryptoApiService {
    constructor(
        @InjectGraphQlClient(EnvironmentKeysEnum.SMART_CONTRACT_CRYPTO_API)
        private readonly _cryptoApiServiceClient: GraphQlClientService,
    ) {}

    async sendTransaction(input: SendTransactionInputType): Promise<boolean> {
        const { query, variables } = generateMutationOp({
                sendTransaction: {
                    __args: {
                        input,
                    },
                },
            },
        )

        await this._cryptoApiServiceClient
            .getClient()
            .request<Pick<Mutation, 'sendTransaction'>>(query, variables)

        return true
    }

    async getUnsignedTransaction(input: SendTransactionInputType): Promise<UnsignedTransactionObjectType> {
        const { query, variables } = generateQueryOp({
            getUnsignedTransaction: {
                __args: {
                    input,
                },
                __typename: true,
                on_UnsignedTransactionObjectType: {
                    ...everything,
                },
                on_ResponseErrorType: {
                    ...everything,
                },
            },
        })

        const { getUnsignedTransaction } = await this._cryptoApiServiceClient
            .getClient()
            .request<Pick<Query, 'getUnsignedTransaction'>>(query, variables)

        if (getUnsignedTransaction.__typename === 'ResponseErrorType') {
            throw new BadRequestException({
                code: getUnsignedTransaction.code,
                message: getUnsignedTransaction.message,
            })
        }

        return getUnsignedTransaction
    }
}
