import {
    BlockchainEnum,
    CryptoModule,
    CryptoService,
} from '@defi-invest/common'
import { Module } from '@nestjs/common'
import { DexModule } from '../dexes/dex.module'
import { UniswapV3DexService } from '../dexes/uniswap-v3/uniswap-v3-dex.service'
import { UniswapV2DexService } from '../dexes/uniswap-v2/uniswap-v2-dex.service'
import { DexAggregatorService } from './dex-aggregator.service'
import { ConfigService } from '@nestjs/config'
import { DexServiceInterface } from 'src/dexes/interfaces/dex-service.interface'


export type DexServicesInterface = {
    [key in BlockchainEnum]?: DexServiceInterface[]
}

@Module({
    imports: [DexModule, CryptoModule],
    providers: [
        {
            provide: DexAggregatorService,
            useFactory: (
                uniswapV2DexService: UniswapV2DexService,
                uniswapV3DexService: UniswapV3DexService,
                configService: ConfigService,
                cryptoService: CryptoService,
            ): DexAggregatorService => {
                return new DexAggregatorService(
                    configService,
                    {
                        [BlockchainEnum.ETH]: [
                            uniswapV2DexService,
                            uniswapV3DexService,
                        ],
                    },
                    cryptoService,
                )
            },
            inject: [
                UniswapV2DexService,
                UniswapV3DexService,
                ConfigService,
                CryptoService,
            ],
        },
    ],
    exports: [DexAggregatorService],
})
/** Class module, use for make dependency injection. */
export class DexAggregatorModule { }
