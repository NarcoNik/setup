import { BlockchainEnum, DexEnum } from '@defi-invest/common'
import { DexSwapTypeEnum } from 'src/dexes/enums/dex-swap-type.enum'
import { FeeAmountEnum } from 'src/dexes/uniswap-v3/enums/fee-amount.enum'

export class SelectDexServiceDto {
    readonly blockchain: BlockchainEnum
    readonly swapType: DexSwapTypeEnum
    readonly data: {
        tokenAddressFrom: string
        tokenAddressTo: string
        amount: string
    }
    readonly dexName?: DexEnum
    readonly feeAmount?: FeeAmountEnum
    readonly formNodeCall?: boolean
}
