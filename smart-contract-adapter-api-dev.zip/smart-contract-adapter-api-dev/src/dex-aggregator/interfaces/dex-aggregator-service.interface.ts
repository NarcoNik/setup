import { SelectDexServiceDto } from '../dtos/select-dex-service.dto'
import { DexAmountOutType } from '../types/dex-amount-out.type'

export interface DexAggregatorServiceInterface {
    getEstimateMaxAmountOut(dto: SelectDexServiceDto): Promise<DexAmountOutType>
}
