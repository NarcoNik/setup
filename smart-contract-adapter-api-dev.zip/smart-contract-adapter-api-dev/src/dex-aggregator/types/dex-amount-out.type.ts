export type DexAmountOutType = {
    amountOut: string
}
