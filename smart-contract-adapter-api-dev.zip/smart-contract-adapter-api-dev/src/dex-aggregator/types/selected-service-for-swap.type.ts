import { DexSwapDto } from 'src/dexes/dtos/dex-swap.dto'
import { DexServiceInterface } from 'src/dexes/interfaces/dex-service.interface'

export type SelectedServiceForSwapType = {
    service: DexServiceInterface
    dexData: DexSwapDto
}
