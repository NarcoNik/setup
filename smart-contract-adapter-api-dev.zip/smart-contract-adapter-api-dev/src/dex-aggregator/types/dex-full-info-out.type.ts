export type DexFullInfoOutType = {
    amountOut: string
    amountMinOut: string,
    defi: string,
    path: PathSwapType[],
}

export type PathSwapType = {
    tokenIn: string
    tokenOut: string,
    poolAddress: string,    
}