import { DexCurrentPriceDto } from 'src/dexes/dtos/dex-swap.dto'
import { DexServiceInterface } from 'src/dexes/interfaces/dex-service.interface'

export type SelectedServiceForCurrentPriceType = {
    service: DexServiceInterface
    dexData: DexCurrentPriceDto
}
