/* eslint-disable @typescript-eslint/no-magic-numbers */
import {
    getPercentageAmount,
    DexEnum,
    BlockchainEnum,
    CryptoService,
} from '@defi-invest/common'
import { Injectable, Logger } from '@nestjs/common'
import { DexAggregatorServiceInterface } from './interfaces/dex-aggregator-service.interface'
import { ConfigService } from '@nestjs/config'
import { DexServicesInterface } from './dex-aggregator.module'
import { SelectDexServiceDto } from './dtos/select-dex-service.dto'
import { DexAmountOutType } from './types/dex-amount-out.type'
import { SelectedServiceForSwapType } from './types/selected-service-for-swap.type'
import {
    DexAmountByCurrentPriceOutType,
    DexEstimateAmountOutType,
} from 'src/dexes/types/dex-estimate-amount-out.type'
import { DexServiceInterface } from 'src/dexes/interfaces/dex-service.interface'
import { DexFullInfoOutType } from './types/dex-full-info-out.type'
import { SelectedServiceForCurrentPriceType } from './types/selected-service-for-current-price.type'

@Injectable()
/** Class service, use for aggregate dex. */
export class DexAggregatorService implements DexAggregatorServiceInterface {
    /** Logger. */
    private readonly _logger = new Logger(DexAggregatorService.name)
    /** Percent has taken from amount. */
    private readonly _amountPercent: string
    /**
     * Constructor.
     * @param _configService Service use for work with ConfigService.
     * @param _dexServices Array of services, which implemented DexServiceInterface.
     * @param _cryptoService Service use for work with crypto provider and contract aggregator
     */
    constructor(
        private readonly _configService: ConfigService,
        private readonly _dexServices: DexServicesInterface,
        private readonly _cryptoService: CryptoService,
    ) {
        const amountPercent = this._configService.get<string>(
            'PERCENT_FROM_AMOUNT',
        )
        if (!amountPercent) {
            throw new Error('PERCENT_FROM_AMOUNT hasn"t been found in .env')
        }
        this._amountPercent = amountPercent
    }

    async getCurrentPriceMaxAmountOut(
        dto: SelectDexServiceDto,
    ): Promise<DexAmountOutType> {
        this._logger.debug(`method: getCurrentPriceMaxAmountOut`)

        const { maxAmountOut } = await this._getMaxAmountByCurrentPriceOut(dto)

        this._logger.debug(`maxAmountOut: ${maxAmountOut}`)
        return {
            amountOut: maxAmountOut.toString(),
        }
    }

    /**
     * Method, use for get estimate max amount out from dex.
     * @param dto Input data.
     * @returns AmountOut and amountOutDesired.
     */
    async getEstimateMaxAmountOut(
        dto: SelectDexServiceDto,
    ): Promise<DexAmountOutType> {
        this._logger.debug(`method: getEstimateMaxAmountOut`)

        const { maxAmountOut } = await this._getBestServiceAndMaxAmountOut(dto)

        this._logger.debug(`maxAmountOut: ${maxAmountOut}`)
        return {
            amountOut: maxAmountOut.toString(),
        }
    }

    async getEstimateFullInfo(
        dto: SelectDexServiceDto,
    ): Promise<DexFullInfoOutType> {
        this._logger.debug(`method: getEstimateMaxAmountOut`)

        const { maxAmountOut, bestService } =
            await this._getBestServiceAndMaxAmountOut(dto)

        this._logger.debug(`maxAmountOut: ${maxAmountOut}`)
        return {
            amountOut: maxAmountOut.toString(),
            amountMinOut: bestService.dexData.data.amountOut,
            defi: bestService.service.dexName,
            path: [
                {
                    tokenIn: dto.data.tokenAddressFrom,
                    tokenOut: dto.data.tokenAddressTo,
                    poolAddress:
                        bestService.dexData.serviceData?.poolAddress || '',
                },
            ],
        }
    }

    /**
     * Method, sue for get dex service for swap and max amount out.
     * @param dto Input data.
     * @returns Dex service for swap and max amount out.
     */
    private async _getBestServiceAndMaxAmountOut(
        dto: SelectDexServiceDto,
    ): Promise<{
        bestService: SelectedServiceForSwapType
        maxAmountOut: bigint
    }> {
        const { blockchain, data, swapType, dexName } = dto

        const dexServices = this._dexServices[blockchain]
        if (!dexServices) {
            throw new Error(
                `Dex services not found for blockchain ${blockchain}`,
            )
        }

        let bestService: SelectedServiceForSwapType =
            {} as SelectedServiceForSwapType

        let maxAmountOut = BigInt(-1)

        if (dexName) {
            const service = this._getServiceByName(dexServices, dexName)

            const virtualSwapResult = await this._getMaxAmountFromService(
                service,
                dto,
            )

            maxAmountOut = BigInt(virtualSwapResult.amountOut.toString())
            bestService = {
                service,
                dexData: {
                    data: {
                        blockchain,
                        ...data,
                        amountOut: getPercentageAmount(
                            virtualSwapResult.amountOut.toString(),
                            this._amountPercent,
                        ).toString(),
                    },
                    serviceData: virtualSwapResult.serviceData,
                    swapType,
                },
            }
        } else {
            for (const service of dexServices) {
                const virtualSwapResult = await this._getMaxAmountFromService(
                    service,
                    dto,
                )

                if (virtualSwapResult.amountOut >= maxAmountOut) {
                    maxAmountOut = virtualSwapResult.amountOut
                    bestService = {
                        service,
                        dexData: {
                            data: {
                                blockchain,
                                ...data,
                                amountOut: getPercentageAmount(
                                    virtualSwapResult.amountOut.toString(),
                                    this._amountPercent,
                                ).toString(),
                            },
                            serviceData: virtualSwapResult.serviceData,
                            swapType,
                        },
                    }
                }
            }
        }
        if (maxAmountOut == BigInt(-1)) {
            /* eslint-disable max-len */
            throw new Error(
                `Pair ${data.tokenAddressFrom}-${
                    data.tokenAddressTo
                } not supported in DEX: ${dexName ? dexName : 'all dexes'}`,
            )
        } else {
            return {
                bestService: bestService as SelectedServiceForSwapType,
                maxAmountOut,
            }
        }
    }

    private async _getMaxAmountByCurrentPriceOut(
        dto: SelectDexServiceDto,
    ): Promise<{
        bestService: SelectedServiceForCurrentPriceType
        maxAmountOut: bigint
    }> {
        const { blockchain, data, swapType, dexName } = dto

        const dexServices = this._dexServices[blockchain]
        if (!dexServices) {
            throw new Error(
                `Dex services not found for blockchain ${blockchain}`,
            )
        }

        let bestService: SelectedServiceForCurrentPriceType =
            {} as SelectedServiceForCurrentPriceType

        let maxAmountOut = BigInt(-1)

        if (dexName) {
            const service = this._getServiceByName(dexServices, dexName)

            const virtualSwapResult =
                await this._getMaxAmountCurrentPriceFromService(service, dto)

            maxAmountOut = BigInt(virtualSwapResult.amountOut.toString())
            bestService = {
                service,
                dexData: {
                    data: {
                        blockchain,
                        ...data,
                        amountOut: getPercentageAmount(
                            virtualSwapResult.amountOut.toString(),
                            this._amountPercent,
                        ).toString(),
                    },
                    serviceData: virtualSwapResult.serviceData,
                    swapType,
                },
            }
        } else {
            for (const service of dexServices) {
                const virtualSwapResult =
                    await this._getMaxAmountCurrentPriceFromService(
                        service,
                        dto,
                    )

                if (virtualSwapResult.amountOut >= maxAmountOut) {
                    maxAmountOut = virtualSwapResult.amountOut
                    bestService = {
                        service,
                        dexData: {
                            data: {
                                blockchain,
                                ...data,
                                amountOut: getPercentageAmount(
                                    virtualSwapResult.amountOut.toString(),
                                    this._amountPercent,
                                ).toString(),
                            },
                            serviceData: virtualSwapResult.serviceData,
                            swapType,
                        },
                    }
                }
            }
        }
        if (maxAmountOut == BigInt(-1)) {
            /* eslint-disable max-len */
            throw new Error(
                `Pair ${data.tokenAddressFrom}-${
                    data.tokenAddressTo
                } not supported in DEX: ${dexName ? dexName : 'all dexes'}`,
            )
        } else {
            return {
                bestService: bestService as SelectedServiceForCurrentPriceType,
                maxAmountOut,
            }
        }
    }

    /**
     * Method, use for get max amount after swap.
     * @param service Dex service for swap.
     * @param dto Data for swap.
     * @returns Max amount from service after swap.
     */
    private async _getMaxAmountFromService(
        service: DexServiceInterface,
        dto: SelectDexServiceDto,
    ): Promise<DexEstimateAmountOutType> {
        const { blockchain, data, swapType, formNodeCall } = dto
        const tradedDex = await this._getTradedDexForPool(
            blockchain,
            data.tokenAddressFrom,
            data.tokenAddressTo,
        )

        if (tradedDex.includes(service.dexName)) {
            const result = await service.getEstimateAmount(
                {
                    blockchain,
                    swapData: data,
                    swapType,
                    feeAmount: dto.feeAmount,
                },
                formNodeCall,
            )
            return result
        } else {
            return {
                amountOut: BigInt('-1'),
                serviceData: undefined,
            }
        }
    }

    private async _getMaxAmountCurrentPriceFromService(
        service: DexServiceInterface,
        dto: SelectDexServiceDto,
    ): Promise<DexAmountByCurrentPriceOutType> {
        const { blockchain, data, swapType, formNodeCall } = dto
        const tradedDex = await this._getTradedDexForPool(
            blockchain,
            data.tokenAddressFrom,
            data.tokenAddressTo,
        )

        if (tradedDex.includes(service.dexName)) {
            const result = await service.getAmountByCurrentPrice(
                {
                    blockchain,
                    swapData: data,
                    swapType,
                    feeAmount: dto.feeAmount,
                },
                formNodeCall,
            )
            return result
        } else {
            return {
                amountOut: BigInt('-1'),
                serviceData: undefined,
            }
        }
    }

    /**
     * Method, use for get service by name.
     * @param dexServices
     * @param [dexName] Dex name.
     * @returns Dex service.
     */
    private _getServiceByName(
        dexServices: DexServiceInterface[],
        dexName?: DexEnum,
    ): DexServiceInterface {
        this._logger.debug(`method: _getService`)
        const result = dexServices.filter(
            (service) => service.dexName === dexName,
        )
        if (result.length === 0) {
            this._logger.error(`Dex service hasn't been found`)
        }
        const dexService = result[0]
        if (!dexService) {
            throw Error('Dex service hasn"t been found')
        }
        this._logger.debug(`selected service: ${dexService.constructor.name}`)
        return dexService
    }

    private async _getTradedDexForPool(
        blockchain: BlockchainEnum,
        token0: string,
        token1: string,
    ): Promise<DexEnum[]> {
        const { contractAggregator } =
            this._cryptoService.getProvider(blockchain)

        const token0Info = await contractAggregator.getContractInfoByAddress(
            token0.toLowerCase(),
        )
        const token1Info = await contractAggregator.getContractInfoByAddress(
            token1.toLowerCase(),
        )

        const token0tradedInDex = token0Info.tradedInDex
            ? token0Info.tradedInDex
            : []
        const token1tradedInDex = token1Info.tradedInDex
            ? token1Info.tradedInDex
            : []

        return token0tradedInDex.filter((x) => token1tradedInDex.includes(x))
    }
}
