import { ApolloServerPluginInlineTraceDisabled } from '@apollo/server/plugin/disabled'
import { ApolloFederationDriver } from '@nestjs/apollo'
import { ConfigModule, ConfigService } from '@nestjs/config'
import { GqlModuleAsyncOptions } from '@nestjs/graphql'
import { EnvironmentKeysEnum } from './config'

export const graphQLConfig: GqlModuleAsyncOptions = {
    imports: [ConfigModule],
    driver: ApolloFederationDriver,
    useFactory: (configService: ConfigService) => ({
        plugins: [ApolloServerPluginInlineTraceDisabled()],
        autoSchemaFile: {
            path: 'schema.graphql',
            federation: 2,
        },
        buildSchemaOptions: {
            dateScalarMode: 'timestamp',
        },
        path: '/graphql',
        introspection: true,
        playground: configService.get<string>(EnvironmentKeysEnum.NODE_ENV) === 'development',
        debug: configService.get<string>(EnvironmentKeysEnum.NODE_ENV) !== 'production',
    }),
    inject: [ConfigService],
}
