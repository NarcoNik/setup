import { ConfigModule, ConfigService } from '@nestjs/config'
import {
    MongooseModuleAsyncOptions,
    MongooseModuleOptions,
} from '@nestjs/mongoose'
import { EnvironmentKeysEnum } from './config'

export const mongooseConfig: MongooseModuleAsyncOptions = {
    imports: [ConfigModule],
    useFactory: (configService: ConfigService): MongooseModuleOptions => {
        const config: MongooseModuleOptions = {}
        config.uri = configService.get<string>(EnvironmentKeysEnum.MONGO_URI)
        const replicaSet = configService.get<string>(EnvironmentKeysEnum.MONGO_REPLICA_SET)
        if (replicaSet) {
            config.replicaSet = replicaSet
        }
        config.autoCreate = true
        config.autoIndex = true

        return config
    },
    inject: [ConfigService],
}
