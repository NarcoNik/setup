import { ConfigModuleOptions } from '@nestjs/config'
import * as Joi from 'joi'

export enum EnvironmentKeysEnum {
    NODE_ENV = 'NODE_ENV',
    HOST = 'HOST',
    PORT = 'PORT',
    NODES = 'NODES',
    DEFI_INVEST_ETH_CONTRACT_ADDRESS = 'DEFI_INVEST_ETH_CONTRACT_ADDRESS',
    DEFI_INVEST_BNB_CONTRACT_ADDRESS = 'DEFI_INVEST_BNB_CONTRACT_ADDRESS',
    ADMIN_ADDRESS = 'ADMIN_ADDRESS',
    REDIS_DEFAULT_CONNECTION = 'REDIS_DEFAULT_CONNECTION',
    REDIS_ADDRESS_DATABASE = 'REDIS_ADDRESS_DATABASE',
    REDIS_ABI_DATABASE = 'REDIS_ABI_DATABASE',
    REDIS_PROJECT_VARIABLES_DATABASE = 'REDIS_PROJECT_VARIABLES_DATABASE',
    REDIS_CONNECTION = 'REDIS_CONNECTION',
    //DEFI_INVEST_BOILERPLATE_2 = 'DEFI_INVEST_BOILERPLATE_2',
    REDIS_PWD = 'REDIS_PWD',
    REDIS_PORT = 'REDIS_PORT',
    MONGO_URI = 'MONGO_URI',
    MONGO_PORT = 'MONGO_PORT',
    MONGO_REPLICA_SET = 'MONGO_REPLICA_SET',
    RMQ_URL = 'RMQ_URL',
    RMQ_EXCHANGES = 'RMQ_EXCHANGES',
    RMQ_ADMIN_TRANSACTIONS_EXCHANGE = 'RMQ_ADMIN_TRANSACTIONS_EXCHANGE',
    RMQ_CATCH_ADMIN_TRANSACTION_ROUTING_KEY = 'RMQ_CATCH_ADMIN_TRANSACTION_ROUTING_KEY',
    RMQ_SMART_CONTRACT_ADAPTER_ADMIN_TRANSACTION_QUEUE = 'RMQ_SMART_CONTRACT_ADAPTER_ADMIN_TRANSACTION_QUEUE',
    SMART_CONTRACT_CRYPTO_API = 'SMART_CONTRACT_CRYPTO_API',
}


const VALIDATION_SCHEMA: Record<EnvironmentKeysEnum, Joi.SchemaLike> = {
    [EnvironmentKeysEnum.NODE_ENV]: Joi.string().required(),
    [EnvironmentKeysEnum.HOST]: Joi.string().required(),
    [EnvironmentKeysEnum.PORT]: Joi.string().required(),

    [EnvironmentKeysEnum.DEFI_INVEST_ETH_CONTRACT_ADDRESS]: Joi.string().required(),
    [EnvironmentKeysEnum.NODES]: Joi.string().required(),
    [EnvironmentKeysEnum.DEFI_INVEST_BNB_CONTRACT_ADDRESS]: Joi.string().required(),
    [EnvironmentKeysEnum.ADMIN_ADDRESS]: Joi.string().required(),

    [EnvironmentKeysEnum.REDIS_DEFAULT_CONNECTION]: Joi.string().required(),
    [EnvironmentKeysEnum.REDIS_ADDRESS_DATABASE]: Joi.string().required(),
    [EnvironmentKeysEnum.REDIS_ABI_DATABASE]: Joi.string().required(),
    [EnvironmentKeysEnum.REDIS_PROJECT_VARIABLES_DATABASE]: Joi.string().required(),
    [EnvironmentKeysEnum.REDIS_CONNECTION]: Joi.string().required(),
    //[EnvironmentKeysEnum.DEFI_INVEST_BOILERPLATE_2]: Joi.string().required(),
    [EnvironmentKeysEnum.REDIS_PWD]: Joi.string().required(),
    [EnvironmentKeysEnum.REDIS_PORT]: Joi.string().required(),

    [EnvironmentKeysEnum.MONGO_URI]: Joi.string().required(),
    [EnvironmentKeysEnum.MONGO_PORT]: Joi.string().required(),
    [EnvironmentKeysEnum.MONGO_REPLICA_SET]: Joi.optional(),

    [EnvironmentKeysEnum.RMQ_URL]: Joi.string().required(),
    [EnvironmentKeysEnum.RMQ_EXCHANGES]: Joi.string().required(),
    [EnvironmentKeysEnum.RMQ_ADMIN_TRANSACTIONS_EXCHANGE]: Joi.string().required(),
    [EnvironmentKeysEnum.RMQ_CATCH_ADMIN_TRANSACTION_ROUTING_KEY]: Joi.string().required(),
    [EnvironmentKeysEnum.RMQ_SMART_CONTRACT_ADAPTER_ADMIN_TRANSACTION_QUEUE]: Joi.string().required(),
    [EnvironmentKeysEnum.SMART_CONTRACT_CRYPTO_API]: Joi.string().required(),
}

export const config: ConfigModuleOptions = {
    envFilePath: ['.env'],
    isGlobal: true,
    expandVariables: true,
    validationSchema: Joi.object(VALIDATION_SCHEMA),
}