import { ConfigModule, ConfigService } from '@nestjs/config'
import { EnvironmentKeysEnum } from './config'
import { AsyncModuleConfig } from '@golevelup/nestjs-modules'
import { RabbitMQConfig, RabbitMQExchangeConfig } from '@golevelup/nestjs-rabbitmq'
import * as dotenv from 'dotenv'

dotenv.config()

const RMQ_ADMIN_TRANSACTIONS_EXCHANGE = process.env[EnvironmentKeysEnum.RMQ_ADMIN_TRANSACTIONS_EXCHANGE] || ''
const RMQ_CATCH_ADMIN_TRANSACTION_ROUTING_KEY
    = process.env[EnvironmentKeysEnum.RMQ_CATCH_ADMIN_TRANSACTION_ROUTING_KEY] || ''
const RMQ_SMART_CONTRACT_ADAPTER_ADMIN_TRANSACTION_QUEUE
    = process.env[EnvironmentKeysEnum.RMQ_SMART_CONTRACT_ADAPTER_ADMIN_TRANSACTION_QUEUE] || ''

const rabbitmqEnvs = {
    RMQ_ADMIN_TRANSACTIONS_EXCHANGE,
    RMQ_CATCH_ADMIN_TRANSACTION_ROUTING_KEY,
    RMQ_SMART_CONTRACT_ADAPTER_ADMIN_TRANSACTION_QUEUE,
}

const rabbitmqConfig: AsyncModuleConfig<RabbitMQConfig> = {
    imports: [ConfigModule],
    useFactory: (configService: ConfigService): RabbitMQConfig => {
        const uri = configService.get<string>(
            EnvironmentKeysEnum.RMQ_URL,
            'amqp://guest:guest@localhost:5672'
        )

        const exchanges: RabbitMQExchangeConfig[] =
            JSON.parse(configService.get<string>(EnvironmentKeysEnum.RMQ_EXCHANGES, '[]'))


        return {
            exchanges,
            uri,
            enableControllerDiscovery: true,
            prefetchCount: 1,
        }
    },
    inject: [ConfigService],
}

export { rabbitmqConfig, rabbitmqEnvs }