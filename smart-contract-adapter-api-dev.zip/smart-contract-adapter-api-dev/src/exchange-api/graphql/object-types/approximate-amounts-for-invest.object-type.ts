import { createUnionType, Field, ObjectType } from '@nestjs/graphql'
import { ResponseErrorType } from '@defi-invest/common'

@ObjectType()
export class TokenAmountAndPercentObjectType {
    @Field(() => String)
    tokenAddress: string

    @Field(() => String)
    percent: string

    @Field(() => String)
    amountVirtual: string
}

@ObjectType()
export class TokensAmountAndPercentObjectType {
    @Field(() => String)
    poolAddress: string

    @Field(() => [TokenAmountAndPercentObjectType])
    tokens: TokenAmountAndPercentObjectType[]
}

@ObjectType()
export class ApproximateAmountsForInvestObjectType {
    @Field(() => [TokensAmountAndPercentObjectType])
    pools: TokensAmountAndPercentObjectType[]
}

export const ApproximateAmountsForInvestObjectUnionType = createUnionType({
    name: 'ApproximateAmountsForInvestObjectUnionType',
    types: () =>
        [ApproximateAmountsForInvestObjectType, ResponseErrorType] as const,
    resolveType(value) {
        if (value.code) {
            return 'ResponseErrorType'
        }
        return 'ApproximateAmountsForInvestObjectType'
    },
})
