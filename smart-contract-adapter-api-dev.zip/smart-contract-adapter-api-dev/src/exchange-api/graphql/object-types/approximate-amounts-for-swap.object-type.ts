import { createUnionType, Field, ObjectType } from '@nestjs/graphql'
import { ResponseErrorType } from '@defi-invest/common'

@ObjectType()
class TokenVirtualAmountSwapObjectType {
    @Field(() => String)
    tokenAddress: string

    @Field(() => Number)
    count: number

    @Field(() => String)
    amountVirtual: string
}

@ObjectType()
export class ApproximateAmountsForSwapObjectType {
    @Field(() => String)
    swapData: string

    @Field(() => [TokenVirtualAmountSwapObjectType])
    tokensAmount: TokenVirtualAmountSwapObjectType[]
}

export const ApproximateAmountsForSwapObjectUnionType = createUnionType({
    name: 'ApproximateAmountsForSwapObjectUnionType',
    types: () =>
        [ApproximateAmountsForSwapObjectType, ResponseErrorType] as const,
    resolveType(value) {
        if (value.code) {
            return 'ResponseErrorType'
        }
        return 'ApproximateAmountsForSwapObjectType'
    },
})
