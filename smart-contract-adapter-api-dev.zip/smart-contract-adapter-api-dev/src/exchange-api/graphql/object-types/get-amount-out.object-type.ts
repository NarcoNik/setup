import { createUnionType, Field, ObjectType } from '@nestjs/graphql'
import { ResponseErrorType } from '@defi-invest/common'

@ObjectType()
export class GetAmountOutObjectType {
    @Field(() => String)
    amountOut: string
}

export const GetAmountOutObjectUnionType = createUnionType({
    name: 'GetAmountOutObjectUnionType',
    types: () => [GetAmountOutObjectType, ResponseErrorType] as const,
    resolveType(value) {
        if (value.code) {
            return 'ResponseErrorType'
        }
        return 'GetAmountOutObjectType'
    },
})
