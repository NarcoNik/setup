import { createUnionType, Field, ObjectType } from '@nestjs/graphql'
import { ResponseErrorType } from '@defi-invest/common'

@ObjectType()
class PathSwapObjectType {
    @Field(() => String)
    tokenIn: string

    @Field(() => String)
    tokenOut: string

    @Field(() => String)
    poolAddress: string
}

@ObjectType()
class GetFullInfoSwapsObjectType {
    @Field(() => String)
    amountOut: string

    @Field(() => String)
    amountMinOut: string

    @Field(() => String)
    defi: string

    @Field(() => [PathSwapObjectType])
    path: PathSwapObjectType[]
}

export const GetFullInfoSwapsObjectUnionType = createUnionType({
    name: 'GetFullInfoSwapsObjectUnionType',
    types: () => [GetFullInfoSwapsObjectType, ResponseErrorType] as const,
    resolveType(value) {
        if (value.code) {
            return 'ResponseErrorType'
        }
        return 'GetFullInfoSwapsObjectType'
    },
})
