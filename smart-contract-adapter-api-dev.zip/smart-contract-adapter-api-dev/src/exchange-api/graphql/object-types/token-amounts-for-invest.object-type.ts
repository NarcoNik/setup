import { createUnionType, Field, ObjectType } from '@nestjs/graphql'
import { ResponseErrorType } from '@defi-invest/common'

@ObjectType()
class TokenVirtualAmountsObjectType {
    @Field(() => String)
    tokenAddress: string

    @Field(() => Number)
    count: number

    @Field(() => String)
    amountVirtual: string
}

@ObjectType()
export class TokenAmountsForInvestObjectType {
    @Field(() => [TokenVirtualAmountsObjectType])
    tokensAmount: TokenVirtualAmountsObjectType[]
}

export const TokenAmountsForInvestObjectUnionType = createUnionType({
    name: 'TokenAmountsForInvestObjectUnionType',
    types: () => [TokenAmountsForInvestObjectType, ResponseErrorType] as const,
    resolveType(value) {
        if (value.code) {
            return 'ResponseErrorType'
        }
        return 'TokenAmountsForInvestObjectType'
    },
})
