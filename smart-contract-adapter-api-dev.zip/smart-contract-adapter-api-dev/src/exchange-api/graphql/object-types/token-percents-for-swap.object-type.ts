import { createUnionType, Field, ObjectType } from '@nestjs/graphql'
import { ResponseErrorType } from '@defi-invest/common'

@ObjectType()
class TokenPercentCountObjectType {
    @Field(() => String)
    tokenAddress: string

    @Field(() => Number)
    count: number

    @Field(() => String)
    percent: string
}

@ObjectType()
export class TokensPercentAmountObjectType {
    @Field(() => [TokenPercentCountObjectType])
    tokensPercent: TokenPercentCountObjectType[]
}

export const TokensPercentAmountObjectUnionType = createUnionType({
    name: 'TokensPercentAmountObjectUnionType',
    types: () => [TokensPercentAmountObjectType, ResponseErrorType] as const,
    resolveType(value) {
        if (value.code) {
            return 'ResponseErrorType'
        }
        return 'TokensPercentAmountObjectType'
    },
})
