import { createUnionType, Field, ObjectType } from '@nestjs/graphql'
import { ResponseErrorType } from '@defi-invest/common'

@ObjectType()
class TokenPercentObjectType {
    @Field(() => String)
    tokenAddress: string

    @Field(() => String)
    percent: string
}

@ObjectType()
class PoolInvestObjectType {
    @Field(() => String)
    poolAddress: string

    @Field(() => [TokenPercentObjectType])
    tokens: TokenPercentObjectType[]
}

@ObjectType()
export class TokensPercentForInvestObjectType {
    @Field(() => [PoolInvestObjectType])
    pools: PoolInvestObjectType[]
}

export const TokensPercentForInvestObjectUnionType = createUnionType({
    name: 'TokensPercentForInvestObjectUnionType',
    types: () => [TokensPercentForInvestObjectType, ResponseErrorType] as const,
    resolveType(value) {
        if (value.code) {
            return 'ResponseErrorType'
        }
        return 'TokensPercentForInvestObjectType'
    },
})
