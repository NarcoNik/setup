import { createUnionType, Field, ObjectType } from '@nestjs/graphql'
import { ResponseErrorType } from '@defi-invest/common'

@ObjectType()
export class SwapDataAfterRemoveObjectType {
    @Field(() => String)
    swapData: string

    @Field(() => String)
    virtualAmount: string
}

export const SwapDataAfterRemoveObjectUnionType = createUnionType({
    name: 'SwapDataAfterRemoveObjectUnionType',
    types: () => [SwapDataAfterRemoveObjectType, ResponseErrorType] as const,
    resolveType(value) {
        if (value.code) {
            return 'ResponseErrorType'
        }
        return 'SwapDataAfterRemoveObjectType'
    },
})
