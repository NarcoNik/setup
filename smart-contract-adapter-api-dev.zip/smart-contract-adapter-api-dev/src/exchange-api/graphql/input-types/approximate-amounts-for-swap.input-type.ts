import { BlockchainEnum } from '@defi-invest/common'
import { Field, InputType } from '@nestjs/graphql'
import { TokenInputType } from '@shared/graphql/input-types'

@InputType()
class TokenPercentSwapInput {
    @Field(() => String)
    tokenAddress: string

    @Field(() => String)
    percent: string

    @Field(() => Number)
    count: number
}

@InputType()
export class GetApproximateAmountsForSwapInputType {
    @Field(() => TokenInputType)
    tokenInput: TokenInputType

    @Field(() => BlockchainEnum)
    blockchain: BlockchainEnum

    @Field(() => [TokenPercentSwapInput])
    tokenPercent: TokenPercentSwapInput[]
}
