import { Field, InputType } from '@nestjs/graphql'
import { BlockchainEnum, DexEnum } from '@defi-invest/common'
import { IsNumberString } from 'class-validator'
import { FeeAmountEnum } from '../../../dexes/uniswap-v3/enums/fee-amount.enum'

@InputType()
export class GetAmountsOutInputType {
    @Field(() => BlockchainEnum)
    blockchain: BlockchainEnum

    @Field(() => String)
    from: string

    @Field(() => String)
    to: string

    @IsNumberString({}, { message: `Field 'amount' is NumberString` })
    @Field(() => String)
    amount: string

    @Field(() => DexEnum, { nullable: true })
    dexName?: DexEnum

    @Field(() => FeeAmountEnum, { nullable: true })
    feeAmount?: FeeAmountEnum

    @Field(() => Boolean, { nullable: true })
    formNodeCall?: boolean
}
