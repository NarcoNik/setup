import { BlockchainEnum } from '@defi-invest/common'
import { Field, InputType } from '@nestjs/graphql'
import {
    PoolWithTokenRatioInput,
    TokenInputType,
} from '@shared/graphql/input-types'

@InputType()
export class GetTokenAmountsForInvestInputType {
    @Field(() => TokenInputType)
    tokenInput: TokenInputType

    @Field(() => BlockchainEnum)
    blockchain: BlockchainEnum

    @Field(() => [PoolWithTokenRatioInput])
    pools: PoolWithTokenRatioInput[]
}
