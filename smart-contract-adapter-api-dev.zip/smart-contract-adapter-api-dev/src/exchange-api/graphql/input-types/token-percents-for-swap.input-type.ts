import { Field, InputType } from '@nestjs/graphql'
import { PoolWithTokenRatioInput } from '@shared/graphql/input-types'

@InputType()
export class GetTokenPercentsInputType {
    @Field(() => [PoolWithTokenRatioInput])
    pools: PoolWithTokenRatioInput[]
}
