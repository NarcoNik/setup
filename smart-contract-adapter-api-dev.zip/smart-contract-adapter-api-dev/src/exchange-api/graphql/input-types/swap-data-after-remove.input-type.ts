import { BlockchainEnum } from '@defi-invest/common'
import { Field, InputType } from '@nestjs/graphql'
import { TokenInputType } from '@shared/graphql/input-types'

@InputType()
class PoolTokenAmountInput {
    @Field(() => String)
    poolAddress: string

    @Field(() => [TokenInputType])
    poolTokens: TokenInputType[]
}

@InputType()
export class GetSwapDataAfterRemoveInputType {
    @Field(() => BlockchainEnum)
    blockchain: BlockchainEnum

    @Field(() => String)
    tokenSwapToAddress: string

    @Field(() => [PoolTokenAmountInput])
    pools: PoolTokenAmountInput[]
}
