import { Field, InputType } from '@nestjs/graphql'

@InputType()
class TokenVirtualAmountInput {
    @Field(() => String)
    tokenAddress: string

    @Field(() => Number)
    count: number

    @Field(() => String)
    amountVirtual: string
}

@InputType()
class TokenPercentInput {
    @Field(() => String)
    tokenAddress: string

    @Field(() => String)
    percent: string
}

@InputType()
class PoolInvestInput {
    @Field(() => String)
    poolAddress: string

    @Field(() => [TokenPercentInput])
    tokensPercent: TokenPercentInput[]
}

@InputType()
export class GetApproximateAmountsForInvestInputType {
    @Field(() => [PoolInvestInput])
    pools: PoolInvestInput[]

    @Field(() => [TokenVirtualAmountInput])
    tokens: TokenVirtualAmountInput[]
}
