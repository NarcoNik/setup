import { Injectable, Logger } from '@nestjs/common';
import BigNumber from 'bignumber.js';
import { DexAggregatorService } from 'src/dex-aggregator/dex-aggregator.service';
import { DexSwapTypeEnum } from 'src/dexes/enums/dex-swap-type.enum';
import { TokenAndCurrencyEnum } from 'src/shared/enums/token-and-currency.enum';
import { GetAmountOutDto, MapSwapDto } from './dtos';
import {
  GetApproximateAmountsForInvestInputType,
  GetTokenPercentsInputType,
  GetTokenAmountsForInvestInputType
} from './graphql/input-types';
import {
  ApproximateAmountsForInvestObjectType,
  TokenAmountAndPercentObjectType,
  TokensPercentForInvestObjectType,
  TokensPercentAmountObjectType,
  TokensAmountAndPercentObjectType,
  TokenAmountsForInvestObjectType
} from './graphql/object-types';
import { DexAmountOutType, DexFullInfoOutType } from 'src/dex-aggregator/types';

const PERCENT_100_SOLIDITY = 100000000; // 100 * 10^6
const PERCENT_100 = 100;

@Injectable()
/** Class service, use for work with any dex. */
export class ExchangeApiService /*implements ExchangeApiServiceInterface*/ {
  /** Logger. */
  private readonly _logger: Logger = new Logger(ExchangeApiService.name);

  /**
   * Constructor.
   * @param _dexAggregator Service, use for get best service for swap.
   * @param _transactionServiceGraphQlClient  Service, use for send request to transaction service.
   * @param _rabbitmqService Service for sending transactions to rabbitmq
   */
  constructor(private readonly _dexAggregator: DexAggregatorService) {}

  /**
   * Method, use for get estimate amount.
   * @param dto Swap dto.
   * @returns Estimate amountOut.
   */
  async getSwapsData(dto: GetAmountOutDto): Promise<DexFullInfoOutType> {
    this._logger.debug(`method: getEstimateAmount`);
    this._logger.debug(`dto: ${JSON.stringify(dto)}`);
    const { blockchain, tokenFrom, tokenTo, dexName, feeAmount, formNodeCall } = dto;
    const { swapType, from, to } = this._getSwapTypeAndPath([tokenFrom, tokenTo]);

    const estimateFullInfotOut = await this._dexAggregator.getEstimateFullInfo({
      blockchain,
      swapType,
      data: {
        amount: dto.amount,
        tokenAddressFrom: from,
        tokenAddressTo: to
      },
      dexName,
      feeAmount,
      formNodeCall
    });
    return estimateFullInfotOut;
  }

  /**
   * Method, use for get estimate amount.
   * @param dto Swap dto.
   * @returns Estimate amountOut.
   */
  async virtualSwap(dto: GetAmountOutDto): Promise<DexAmountOutType> {
    this._logger.debug(`method: getEstimateAmount`);
    this._logger.debug(`dto: ${JSON.stringify(dto)}`);
    const { blockchain, tokenFrom, tokenTo, dexName, feeAmount } = dto;
    const { swapType, from, to } = this._getSwapTypeAndPath([tokenFrom, tokenTo]);

    const estimateMaxAmountOut = await this._dexAggregator.getEstimateMaxAmountOut({
      blockchain,
      swapType,
      data: {
        amount: dto.amount,
        tokenAddressFrom: from,
        tokenAddressTo: to
      },
      dexName,
      feeAmount
    });
    return estimateMaxAmountOut;
  }

  async exchangeByCurrentPrice(dto: GetAmountOutDto): Promise<DexAmountOutType> {
    this._logger.debug(`method: exchangeByCurrentPrice`);
    this._logger.debug(`dto: ${JSON.stringify(dto)}`);
    const { blockchain, tokenFrom, tokenTo, dexName, feeAmount } = dto;
    const { swapType, from, to } = this._getSwapTypeAndPath([tokenFrom, tokenTo]);

    const estimateMaxAmountOut = await this._dexAggregator.getCurrentPriceMaxAmountOut({
      blockchain,
      swapType,
      data: {
        amount: dto.amount,
        tokenAddressFrom: from,
        tokenAddressTo: to
      },
      dexName,
      feeAmount
    });
    return estimateMaxAmountOut;
  }

  // 1)
  async getTokenAmountsForInvest({
    blockchain,
    pools,
    tokenInput
  }: GetTokenAmountsForInvestInputType): Promise<TokenAmountsForInvestObjectType> {
    const { tokensPercent } = this.getTokenAmountPercents({ pools });

    const inputTokenPercent = tokensPercent.find(elem => elem.tokenAddress.toLowerCase() === tokenInput.tokenAddress.toLowerCase());
    if (!inputTokenPercent) {
      throw Error('no valid tokenInput');
    }
    const inputPercent = inputTokenPercent.percent;

    const virtualAmountTokens: {
      tokenAddress: string;
      count: number;
      amountVirtual: string;
    }[] = [];

    const queue: Promise<void>[] = [];
    tokensPercent.forEach(({ tokenAddress: tokenTo, percent, count }) => {
      const amount = BigNumber(tokenInput.tokenAmount).multipliedBy(percent).dividedBy(inputPercent).dividedBy(PERCENT_100).toFixed(0);
      if (tokenInput.tokenAddress.toLowerCase() != tokenTo.toLowerCase()) {
        queue.push(
          this.getSwapsData({
            blockchain,
            amount,
            tokenFrom: tokenInput.tokenAddress,
            tokenTo,
            formNodeCall: true
          }).then(({ amountOut }) => {
            virtualAmountTokens.push({
              tokenAddress: tokenTo,
              count,
              amountVirtual: amountOut
            });
          })
        );
      } else {
        virtualAmountTokens.push({
          tokenAddress: tokenTo,
          count,
          amountVirtual: amount
        });
      }
    });

    await Promise.all(queue);

    return {
      tokensAmount: virtualAmountTokens
    };
  }

  // 2)
  getTokenAmountPercents({ pools }: GetTokenPercentsInputType): TokensPercentAmountObjectType {
    //validate percent
    let amountTokenInPercent = BigNumber('0');
    pools.forEach(({ tokensRatio, poolWeightInPercent }) => {
      amountTokenInPercent = amountTokenInPercent.plus(poolWeightInPercent);
      let amountTokenRatioPool = BigNumber('0');
      tokensRatio.forEach(({ percent: tokenRatioPool }) => {
        amountTokenRatioPool = amountTokenRatioPool.plus(tokenRatioPool);
      });
      if (!amountTokenRatioPool.eq(PERCENT_100)) {
        throw Error('no valid tokenRatioPool');
      }
    });
    if (!amountTokenInPercent.eq(PERCENT_100)) {
      throw Error('no valid tokenInPercent');
    }

    // calc percent for swaps
    const mapSwaps = new Map<string, MapSwapDto>();
    pools.forEach(({ tokensRatio, poolWeightInPercent }) => {
      tokensRatio.forEach(({ tokenAddress, percent: tokenRatioPool }) => {
        let amountPercent = mapSwaps.get(tokenAddress.toLowerCase());
        if (!amountPercent) {
          amountPercent = { percent: '0', count: 0 };
        }
        amountPercent.percent = BigNumber(amountPercent.percent)
          .plus(BigNumber(poolWeightInPercent).multipliedBy(tokenRatioPool).dividedBy(PERCENT_100).toFixed())
          .toFixed();
        amountPercent.count++;
        mapSwaps.set(tokenAddress.toLowerCase(), amountPercent);
      });
    });

    const tokensPercent: {
      tokenAddress: string;
      percent: string;
      count: number;
    }[] = [];
    mapSwaps.forEach((swap, tokenAddress) => {
      swap.percent = BigNumber(swap.percent).toFixed();
      tokensPercent.push({
        tokenAddress,
        ...swap
      });
    });

    return {
      tokensPercent
    };
  }

  // 3)
  getTokenPercentsForInvest({ pools: poolsInvest }: GetTokenPercentsInputType): TokensPercentForInvestObjectType {
    //validate percent
    let amountTokenInPercent = BigNumber('0');
    poolsInvest.forEach(({ tokensRatio, poolWeightInPercent }) => {
      amountTokenInPercent = amountTokenInPercent.plus(poolWeightInPercent);
      let amountTokenRatioPool = BigNumber('0');
      tokensRatio.forEach(({ percent: tokenRatioPool }) => {
        amountTokenRatioPool = amountTokenRatioPool.plus(tokenRatioPool);
      });
      if (!amountTokenRatioPool.eq(PERCENT_100)) {
        throw Error('no valid tokenRatioPool');
      }
    });
    if (!amountTokenInPercent.eq(PERCENT_100)) {
      throw Error('no valid tokenInPercent');
    }

    // calc percent for swaps
    const mapSwaps = new Map<string, MapSwapDto>();
    poolsInvest.forEach(({ tokensRatio, poolWeightInPercent }) => {
      tokensRatio.forEach(({ tokenAddress, percent: tokenRatioPool }) => {
        let amountPercent = mapSwaps.get(tokenAddress.toLowerCase());
        if (!amountPercent) {
          amountPercent = { percent: '0', count: 0 };
        }
        amountPercent.percent = BigNumber(amountPercent.percent)
          .plus(BigNumber(poolWeightInPercent).multipliedBy(tokenRatioPool).toFixed())
          .toFixed();
        amountPercent.count++;
        mapSwaps.set(tokenAddress.toLowerCase(), amountPercent);
      });
    });

    // calc percent for invest
    const mapInvest = new Map<
      string,
      {
        percent: string;
        count: number;
      }
    >();

    const pools = poolsInvest.map(({ poolAddress, poolWeightInPercent, tokensRatio }) => {
      return {
        poolAddress,
        tokens: tokensRatio.map(({ tokenAddress, percent: tokenRatioPool }) => {
          let amountPercentInvest = mapInvest.get(tokenAddress.toLowerCase());
          const amountPercentSwap = mapSwaps.get(tokenAddress.toLowerCase());

          if (!amountPercentSwap) {
            throw Error('Not found info for swap');
          }
          if (!amountPercentInvest) {
            amountPercentInvest = {
              count: amountPercentSwap.count,
              percent: BigNumber(PERCENT_100_SOLIDITY).toFixed()
            };
          }

          let percent = '0';
          amountPercentInvest.count--;
          if (amountPercentInvest.count > 0) {
            percent = BigNumber(PERCENT_100_SOLIDITY)
              .multipliedBy(poolWeightInPercent)
              .multipliedBy(tokenRatioPool)
              .dividedBy(amountPercentSwap.percent)
              .toFixed(0);
          } else {
            percent = amountPercentInvest.percent;
          }
          amountPercentInvest.percent = BigNumber(amountPercentInvest.percent).minus(percent).toFixed();
          mapInvest.set(tokenAddress.toLowerCase(), amountPercentInvest);
          return {
            tokenAddress,
            percent
          };
        })
      };
    });

    return {
      pools
    };
  }

  // 4
  async getApproximateAmountsForInvest({
    pools: poolsInvest,
    tokens: tokensVirtualAmount
  }: GetApproximateAmountsForInvestInputType): Promise<ApproximateAmountsForInvestObjectType> {
    const mapSwaps = new Map<string, MapSwapDto>();
    tokensVirtualAmount.forEach(({ count, tokenAddress, amountVirtual }) => {
      mapSwaps.set(tokenAddress.toLowerCase(), {
        count,
        percent: '0',
        amountVirtual
      });
    });

    const pools: TokensAmountAndPercentObjectType[] = [];

    poolsInvest.forEach(({ tokensPercent, poolAddress }) => {
      const tokens: TokenAmountAndPercentObjectType[] = [];

      tokensPercent.forEach(elemToken => {
        const amountPercentSwap = mapSwaps.get(elemToken.tokenAddress.toLowerCase());
        if (!amountPercentSwap || !amountPercentSwap.amountVirtual) {
          throw Error('not found data for swap');
        }
        tokens.push({
          ...elemToken,
          amountVirtual: BigNumber(amountPercentSwap.amountVirtual)
            .multipliedBy(elemToken.percent)
            .dividedBy(PERCENT_100_SOLIDITY)
            .toFixed(0)
        });
      });
      pools.push({ tokens, poolAddress });
    });

    return {
      pools
    };
  }

  /**
   * Method, use for get swap type and path.
   * @param path Array of token name.
   * @returns swap type and array of preparer token.
   */
  private _getSwapTypeAndPath(path: string[]): {
    swapType: DexSwapTypeEnum;
    from: string;
    to: string;
  } {
    const [from, to] = path;
    if (!from || !to) {
      throw new Error('Invalid path');
    }
    if (from === TokenAndCurrencyEnum.ETH) {
      return {
        swapType: DexSwapTypeEnum.ETH_FOR_TOKEN,
        from: TokenAndCurrencyEnum.WETH,
        to
      };
    }
    if (from === TokenAndCurrencyEnum.BNB) {
      return {
        swapType: DexSwapTypeEnum.ETH_FOR_TOKEN,
        from: TokenAndCurrencyEnum.WBNB,
        to
      };
    }
    if (to === TokenAndCurrencyEnum.ETH) {
      return {
        swapType: DexSwapTypeEnum.TOKEN_FOR_ETH,
        from,
        to: TokenAndCurrencyEnum.WETH
      };
    }
    if (to === TokenAndCurrencyEnum.BNB) {
      return {
        swapType: DexSwapTypeEnum.TOKEN_FOR_ETH,
        from,
        to: TokenAndCurrencyEnum.WBNB
      };
    }
    return {
      swapType: DexSwapTypeEnum.TOKEN_FOR_TOKEN,
      from,
      to
    };
  }
}
