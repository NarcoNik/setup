import { BlockchainEnum, DexEnum } from '@defi-invest/common'
import { FeeAmountEnum } from 'src/dexes/uniswap-v3/enums/fee-amount.enum'

export class GetAmountOutDto {
    blockchain: BlockchainEnum
    amount: string
    tokenFrom: string
    tokenTo: string
    dexName?: DexEnum
    feeAmount?: FeeAmountEnum
    formNodeCall?: boolean
}
