export class MapSwapDto {
    percent: string
    count: number
    amountVirtual?: string
}
