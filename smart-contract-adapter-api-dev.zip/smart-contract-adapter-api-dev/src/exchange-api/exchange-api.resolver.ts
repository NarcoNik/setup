import { Logger } from '@nestjs/common';
import { Args, Resolver, Query } from '@nestjs/graphql';
import { ExchangeApiService } from './exchange-api.service';
import {
  ApproximateAmountsForInvestObjectUnionType,
  GetAmountOutObjectUnionType,
  GetFullInfoSwapsObjectUnionType,
  TokenAmountsForInvestObjectUnionType,
  TokensPercentForInvestObjectUnionType,
  TokensPercentAmountObjectUnionType
} from './graphql/object-types';
import {
  GetApproximateAmountsForInvestInputType,
  GetAmountsOutInputType,
  GetTokenPercentsInputType,
  GetTokenAmountsForInvestInputType
} from './graphql/input-types';

@Resolver()
/** Class resolver, use for handle GraphQl query and mutation. */
export class ExchangeApiResolver /*implements ExchangeApiResolverInterface*/ {
  /** Logger. */
  private readonly _logger = new Logger(ExchangeApiResolver.name);

  constructor(private readonly _exchangeApi: ExchangeApiService) {}

  /**
   * Method, query handler, use for get amountsOut.
   * @param input Swap input.
   * @returns AmountOut and amountOutDesired.
   */
  @Query(() => GetAmountOutObjectUnionType)
  async virtualSwap(@Args('input') input: GetAmountsOutInputType): Promise<typeof GetAmountOutObjectUnionType> {
    this._logger.log(`method: virtualSwap`);
    this._logger.debug(`input: ${JSON.stringify(input)}`);
    const { blockchain, from, to, amount, dexName, feeAmount } = input;

    const date = new Date();
    const testTime = `${date.getMinutes()}m-${date.getSeconds()}s-${date.getMilliseconds()}ms`;
    console.time('virtualSwap ' + testTime);

    const estimateAmount = await this._exchangeApi.virtualSwap({
      blockchain,
      dexName,
      tokenFrom: from,
      tokenTo: to,
      amount,
      feeAmount
    });

    console.timeEnd('virtualSwap ' + testTime);
    return {
      amountOut: estimateAmount.amountOut
    };
  }

  @Query(() => GetAmountOutObjectUnionType)
  async exchangeByCurrentPrice(@Args('input') input: GetAmountsOutInputType): Promise<typeof GetAmountOutObjectUnionType> {
    this._logger.log(`method: exchangeByCurrentPrice`);
    this._logger.debug(`input: ${JSON.stringify(input)}`);
    const { blockchain, from, to, amount, dexName, feeAmount } = input;

    const date = new Date();
    const testTime = `${date.getMinutes()}m-${date.getSeconds()}s-${date.getMilliseconds()}ms`;
    console.time('exchangeByCurrentPrice ' + testTime);

    const estimateAmount = await this._exchangeApi.exchangeByCurrentPrice({
      blockchain,
      dexName,
      tokenFrom: from,
      tokenTo: to,
      amount,
      feeAmount
    });

    console.timeEnd('exchangeByCurrentPrice ' + testTime);
    return {
      amountOut: estimateAmount.amountOut
    };
  }

  /**
   * Method, query handler, use for get swap info.
   * @param input Swap input.
   * @returns Swap Info
   */
  @Query(() => GetFullInfoSwapsObjectUnionType)
  async getSwapsData(@Args('input') input: GetAmountsOutInputType): Promise<typeof GetFullInfoSwapsObjectUnionType> {
    this._logger.log(`method: getSwapsData`);
    this._logger.debug(`input: ${JSON.stringify(input)}`);
    const { blockchain, from, to, amount, dexName, feeAmount, formNodeCall } = input;

    const date = new Date();
    const testTime = `${date.getMinutes()}m-${date.getSeconds()}s-${date.getMilliseconds()}ms`;
    console.time('getSwapsData ' + testTime);

    const estimateSwaps = await this._exchangeApi.getSwapsData({
      blockchain,
      dexName,
      tokenFrom: from,
      tokenTo: to,
      amount,
      feeAmount,
      formNodeCall
    });

    console.timeEnd('getSwapsData ' + testTime);
    return estimateSwaps;
  }

  // 1
  @Query(() => TokenAmountsForInvestObjectUnionType)
  async getTokenAmountsForInvest(
    @Args('input') input: GetTokenAmountsForInvestInputType
  ): Promise<typeof TokenAmountsForInvestObjectUnionType> {
    this._logger.log(`method: getTokenAmountsForInvest`);
    this._logger.debug(`input: ${JSON.stringify(input)}`);

    const date = new Date();
    const testTime = `${date.getMinutes()}m-${date.getSeconds()}s-${date.getMilliseconds()}ms`;
    console.time('getTokenAmountsForInvest ' + testTime);

    const amounts = await this._exchangeApi.getTokenAmountsForInvest(input);

    console.timeEnd('getTokenAmountsForInvest ' + testTime);
    return amounts;
  }

  // 2
  @Query(() => TokensPercentAmountObjectUnionType)
  async getTokenAmountPercents(@Args('input') input: GetTokenPercentsInputType): Promise<typeof TokensPercentAmountObjectUnionType> {
    this._logger.log(`method: getTokenAmountPercents`);
    this._logger.debug(`input: ${JSON.stringify(input)}`);

    const date = new Date();
    const testTime = `${date.getMinutes()}m-${date.getSeconds()}s-${date.getMilliseconds()}ms`;
    console.time('getTokenAmountPercents ' + testTime);

    const tokensPercents = this._exchangeApi.getTokenAmountPercents(input);

    console.timeEnd('getTokenAmountPercents ' + testTime);
    return tokensPercents;
  }

  // 3
  @Query(() => TokensPercentForInvestObjectUnionType)
  async getTokenPercentsForInvest(@Args('input') input: GetTokenPercentsInputType): Promise<typeof TokensPercentForInvestObjectUnionType> {
    this._logger.log(`method: getTokenPercentsForInvest`);
    this._logger.debug(`input: ${JSON.stringify(input)}`);

    const date = new Date();
    const testTime = `${date.getMinutes()}m-${date.getSeconds()}s-${date.getMilliseconds()}ms`;
    console.time('getTokenPercentsForInvest ' + testTime);

    const tokensPercents = this._exchangeApi.getTokenPercentsForInvest(input);

    console.timeEnd('getTokenPercentsForInvest ' + testTime);
    return tokensPercents;
  }

  // 4
  @Query(() => ApproximateAmountsForInvestObjectUnionType)
  async getApproximateAmountsForInvest(
    @Args('input') input: GetApproximateAmountsForInvestInputType
  ): Promise<typeof ApproximateAmountsForInvestObjectUnionType> {
    this._logger.log(`method: getApproximateAmountsForInvest`);
    this._logger.debug(`input: ${JSON.stringify(input)}`);

    const date = new Date();
    const testTime = `${date.getMinutes()}m-${date.getSeconds()}s-${date.getMilliseconds()}ms`;
    console.time('getApproximateAmountsForInvest ' + testTime);

    const amounts = await this._exchangeApi.getApproximateAmountsForInvest(input);

    console.timeEnd('getApproximateAmountsForInvest ' + testTime);
    return amounts;
  }
}
