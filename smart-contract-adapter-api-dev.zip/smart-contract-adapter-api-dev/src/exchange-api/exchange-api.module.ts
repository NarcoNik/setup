import { Module } from '@nestjs/common';
import { ExchangeApiResolver } from './exchange-api.resolver';
import { ExchangeApiService } from './exchange-api.service';
import { DexAggregatorModule } from 'src/dex-aggregator/dex-aggregator.module';

@Module({
  imports: [DexAggregatorModule],
  providers: [ExchangeApiResolver, ExchangeApiService],
  exports: [ExchangeApiService]
})
/** Class module, use for make dependency injection. */
export class ExchangeApiModule {}
