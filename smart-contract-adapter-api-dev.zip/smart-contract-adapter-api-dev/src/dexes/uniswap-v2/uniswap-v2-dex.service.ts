/* eslint-disable @typescript-eslint/no-magic-numbers */
import {
    CryptoService,
    DexEnum,
    UniswapV2ContractEnum,
} from '@defi-invest/common'
import { Injectable, Logger } from '@nestjs/common'
import {
    UniswapV2Router__factory,
    UniswapFactory__factory as UniswapV2Factory__factory,
    UniswapV2Pair__factory,
} from '../../../typechain'
import { DexServiceInterface } from '../interfaces/dex-service.interface'
import { DexGetEstimateAmountDto } from '../dtos/dex-get-estimate-amount.dto'
import {
    DexAmountByCurrentPriceOutType,
    DexEstimateAmountOutType,
} from '../types/dex-estimate-amount-out.type'
import BigNumber from 'bignumber.js'

@Injectable()
/**
 * Class service, use for work with uniswap v2 DEX.
 * @link More information on https://docs.uniswap.org/protocol/V2/introduction.
 * */
export class UniswapV2DexService implements DexServiceInterface {
    /** Dex name. */
    readonly dexName: DexEnum = DexEnum.UNISWAPV2
    /** Logger. */
    private readonly _logger = new Logger(UniswapV2DexService.name)

    /**
     * Constructor.
     * @param _cryptoService Service use for work with crypto provider and contract aggregator
     */
    constructor(private readonly _cryptoService: CryptoService) {}

    async getAmountByCurrentPrice(
        dto: DexGetEstimateAmountDto,
        formNodeCall = false,
    ): Promise<DexAmountByCurrentPriceOutType> {
        this._logger.debug(`method: getAmountByCurrentPrice`)

        if (formNodeCall) {
            return await this._getAmountByCurrentPriceFromNode(dto)
        }

        return await this._getAmountByCurrentPriceFromRate(dto)
    }

    /**
     * Method, use for get estimate amount.
     * @param dto Dex get estimate amount dto.
     * @returns Object of DexEstimateAmountOutType.
     * @link More information on https://docs.uniswap.org/protocol/V2/reference/smart-contracts/router-02#getamountsout.
     */
    async getEstimateAmount(
        dto: DexGetEstimateAmountDto,
        formNodeCall = false,
    ): Promise<DexEstimateAmountOutType> {
        this._logger.debug(`method: getEstimateAmount`)

        if (formNodeCall) {
            return await this._getEstimateAmountFromNodeCall(dto)
        }

        return await this._getEstimateAmountFromRate(dto)
    }

    /**
     * Method, use for get estimate amount without commission.
     * @param dto Dex get estimate amount dto.
     * @returns Object of DexEstimateAmountOutType.
     */
    private async _getAmountByCurrentPriceFromNode(
        dto: DexGetEstimateAmountDto,
    ): Promise<DexAmountByCurrentPriceOutType> {
        this._logger.debug(`method : _getAmountByCurrentPriceFromNode`)
        this._logger.debug(`dto: ${JSON.stringify(dto)}`)
        const {
            blockchain,
            swapData: {
                tokenAddressFrom,
                tokenAddressTo,
                amount: amountDesired,
            },
        } = dto

        const { baseProvider, contractAggregator } =
            this._cryptoService.getProvider(blockchain)

        const amount = amountDesired

        const factoryAddress = await contractAggregator.getAddressByName(
            UniswapV2ContractEnum.UniswapV2Factory,
        )
        const factoryContract = UniswapV2Factory__factory.connect(
            factoryAddress,
            baseProvider,
        )

        const pairAddress = await factoryContract.getPair(
            tokenAddressFrom,
            tokenAddressTo,
        )
        const pairContract = UniswapV2Pair__factory.connect(
            pairAddress,
            baseProvider,
        )

        const { _reserve0, _reserve1 } = await pairContract.getReserves()
        this._logger.debug(
            `_reserve0: ${_reserve0.toString()}, _reserve1: ${_reserve1.toString()}`,
        )

        const token0address = await pairContract.token0()
        const reserve0 = BigNumber(_reserve0.toString())
        const reserve1 = BigNumber(_reserve1.toString())
        const currentPrice = reserve1.dividedBy(reserve0)

        let amountOut: BigNumber
        if (tokenAddressFrom === token0address) {
            amountOut = BigNumber(amount).multipliedBy(currentPrice)
        } else {
            amountOut = BigNumber(amount).multipliedBy(currentPrice.pow(-1))
        }

        this._logger.debug(`amountOut: ${amountOut}`)
        return {
            amountOut: BigInt(amountOut.toFixed(0)),
            serviceData: undefined,
        }
    }

    private async _getAmountByCurrentPriceFromRate(
        dto: DexGetEstimateAmountDto,
    ): Promise<DexAmountByCurrentPriceOutType> {
        return await this._getAmountByCurrentPriceFromNode(dto)
    }

    private async _getEstimateAmountFromNodeCall(
        dto: DexGetEstimateAmountDto,
    ): Promise<DexEstimateAmountOutType> {
        const {
            blockchain,
            swapData: { amount, tokenAddressFrom, tokenAddressTo },
        } = dto
        this._logger.debug(`method: getEstimateAmountFromNodeCall`)
        this._logger.debug(`dto: ${JSON.stringify(dto)}`)

        const { baseProvider, contractAggregator } =
            this._cryptoService.getProvider(blockchain)

        const path: string[] = [tokenAddressFrom, tokenAddressTo]

        const routerAddress = await contractAggregator.getAddressByName(
            UniswapV2ContractEnum.UniswapV2Router02,
        )
        const routerContract = UniswapV2Router__factory.connect(routerAddress, {
            provider: baseProvider,
        })

        const factoryAddress = await contractAggregator.getAddressByName(
            UniswapV2ContractEnum.UniswapV2Factory,
        )
        const factoryContract = UniswapV2Factory__factory.connect(
            factoryAddress,
            baseProvider,
        )
        const poolAddress = await factoryContract.getPair(
            tokenAddressFrom,
            tokenAddressTo,
        )

        try {
            const amounts = await routerContract.getAmountsOut.staticCall(
                amount,
                path,
            )
            const amountOut = amounts[1]
            if (!amountOut) {
                throw new Error('amountOut is undefined')
            }
            this._logger.debug(`amounts: [${amounts}]`)
            return {
                amountOut,
                serviceData: {
                    poolAddress,
                },
            }
        } catch (err) {
            this._logger.warn(`getAmountsOut error: ${err.message}`)
            return {
                amountOut: BigInt(-1),
                serviceData: {
                    poolAddress: '',
                },
            }
        }
    }

    private async _getEstimateAmountFromRate(
        dto: DexGetEstimateAmountDto,
    ): Promise<DexEstimateAmountOutType> {
        return await this._getEstimateAmountFromNodeCall(dto)
    }
}
