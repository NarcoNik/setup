export type UniswapV2ServiceData = {
    poolAddress: string
}
