import { Module } from '@nestjs/common'
import { ConfigModule } from '@nestjs/config'
import { UniswapV2DexService } from './uniswap-v2-dex.service'
import { CryptoModule } from '@defi-invest/common'

@Module({
    imports: [ConfigModule, CryptoModule],
    providers: [UniswapV2DexService],
    exports: [UniswapV2DexService],
})
/** Class module, use for make dependency injection. */
export class UniswapV2DexModule {}
