import { DexSwapTypeEnum } from '../enums/dex-swap-type.enum'
import {
    DexServiceDataType,
    DexServiceSwapDataType,
} from '../types/dex-service-data.type'
import { DexSwapDataType } from '../types/dex-swap-data.type'

export class DexSwapDto {
    swapType: DexSwapTypeEnum
    data: DexSwapDataType
    serviceData: DexServiceSwapDataType
}

export class DexCurrentPriceDto {
    swapType: DexSwapTypeEnum
    data: DexSwapDataType
    serviceData: DexServiceDataType
}
