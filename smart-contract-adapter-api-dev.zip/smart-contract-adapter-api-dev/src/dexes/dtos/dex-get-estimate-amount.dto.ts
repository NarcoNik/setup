import { BlockchainEnum } from '@defi-invest/common'
import { DexSwapTypeEnum } from '../enums/dex-swap-type.enum'
import { FeeAmountEnum } from '../uniswap-v3/enums/fee-amount.enum'

export class DexGetEstimateAmountDto {
    blockchain: BlockchainEnum
    swapType: DexSwapTypeEnum
    swapData: {
        amount: string
        tokenAddressFrom: string
        tokenAddressTo: string
    }
    feeAmount?: FeeAmountEnum
}
