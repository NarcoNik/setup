import { Module } from '@nestjs/common'
import { UniswapV2DexModule } from './uniswap-v2/uniswap-v2-dex.module'
import { UniswapV3DexModule } from './uniswap-v3/uniswap-v3-dex.module'
import { CryptoModule } from '@defi-invest/common'

@Module({
    imports: [UniswapV2DexModule, UniswapV3DexModule,CryptoModule],
    exports: [UniswapV2DexModule, UniswapV3DexModule],
})
/** Class module, use for make dependency injection. */
export class DexModule {}
