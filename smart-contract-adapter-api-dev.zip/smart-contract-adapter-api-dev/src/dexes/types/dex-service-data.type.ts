import { UniswapV2ServiceData } from '../uniswap-v2/types/uniswap-v2-service-data.type'
import { UniswapV3ServiceData } from '../uniswap-v3/types/uniswap-v3-service-data.type'
import { UniswapV3ServiceSwapData } from '../uniswap-v3/types/uniswap-v3-service-swap-data.type'

export type DexServiceDataType = UniswapV3ServiceData | undefined

export type DexServiceSwapDataType =
    | UniswapV3ServiceSwapData
    | UniswapV2ServiceData
    | undefined
