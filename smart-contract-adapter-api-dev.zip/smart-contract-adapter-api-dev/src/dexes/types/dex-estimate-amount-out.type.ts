import {
    DexServiceDataType,
    DexServiceSwapDataType,
} from './dex-service-data.type'

export type DexEstimateAmountOutType = {
    amountOut: bigint
    serviceData: DexServiceSwapDataType
}

export type DexAmountByCurrentPriceOutType = {
    amountOut: bigint
    serviceData: DexServiceDataType
}
