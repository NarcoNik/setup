import { BlockchainEnum } from '@defi-invest/common'

export type DexSwapDataType = {
    blockchain: BlockchainEnum
    amount: string
    amountOut: string
    tokenAddressFrom: string
    tokenAddressTo: string
}
