import { DexEnum } from '@defi-invest/common'
import { DexGetEstimateAmountDto } from '../dtos/dex-get-estimate-amount.dto'
import {
    DexAmountByCurrentPriceOutType,
    DexEstimateAmountOutType,
} from '../types/dex-estimate-amount-out.type'

export interface DexServiceInterface {
    dexName: DexEnum

    getEstimateAmount(
        dto: DexGetEstimateAmountDto,
        formNodeCall?: boolean,
    ): Promise<DexEstimateAmountOutType>

    getAmountByCurrentPrice(
        dto: DexGetEstimateAmountDto,
        formNodeCall?: boolean,
    ): Promise<DexAmountByCurrentPriceOutType>
}
