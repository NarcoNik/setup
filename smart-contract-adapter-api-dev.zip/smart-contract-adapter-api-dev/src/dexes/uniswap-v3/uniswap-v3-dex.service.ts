/* eslint-disable @typescript-eslint/no-magic-numbers */
import { BlockchainEnum, CryptoService, DexEnum, toBigNumberEthers, UniswapV3ContractEnum } from '@defi-invest/common';
import { Injectable, Logger } from '@nestjs/common';
import { UniswapV3Quoter__factory, UniswapV3Factory__factory, UniswapV3Pair__factory as UniswapV3Pool__factory } from '../../../typechain';
import { DexServiceInterface } from '../interfaces/dex-service.interface';
import { DexGetEstimateAmountDto } from '../dtos/dex-get-estimate-amount.dto';
import { DexAmountByCurrentPriceOutType, DexEstimateAmountOutType } from '../types/dex-estimate-amount-out.type';
import { FeeAmountEnum } from './enums/fee-amount.enum';
import { AmountOutMaxType } from './types/amount-out-max.type';
import { FEE_AMOUNT } from './constants/fee-amount.const';
import BigNumber from 'bignumber.js';
import { FeeAmount, Pool } from '@uniswap/v3-sdk';
import { Token } from '@uniswap/sdk-core';
//import { CHAIN_ID } from 'src/defi-projects/projects/uniswap-v3/classes/operation.class'
import { DexServiceDataType } from '../types/dex-service-data.type';

@Injectable()
/**
 * Class service, use for work with uniswap v3 DEX.
 * @link More information on https://docs.uniswap.org/protocol/introduction.
 */
export class UniswapV3DexService implements DexServiceInterface {
  /** Dex name. */
  readonly dexName: DexEnum = DexEnum.UNISWAPV3;
  /** Logger. */
  private readonly _logger = new Logger(UniswapV3DexService.name);

  /**
   * Constructor.
   * @param _cryptoService Service use for work with crypto provider and contract aggregator
   */
  constructor(private readonly _cryptoService: CryptoService) {}

  async getAmountByCurrentPrice(dto: DexGetEstimateAmountDto, formNodeCall = false): Promise<DexAmountByCurrentPriceOutType> {
    this._logger.debug(`method: getAmountByCurrentPrice`);
    const {
      blockchain,
      swapData: { amount, tokenAddressFrom, tokenAddressTo },
      feeAmount
    } = dto;

    if (feeAmount) {
      return {
        amountOut: await this._getAmountByCurrentPrice(
          {
            blockchain,
            amount,
            tokenAddressFrom,
            tokenAddressTo,
            feeAmount
          },
          formNodeCall
        ),
        serviceData: { fee: feeAmount }
      };
    } else {
      let maxEstimateAmount = BigInt(-1);
      let result: {
        serviceData: DexServiceDataType;
        amountOut: bigint;
      } = {
        serviceData: { fee: FeeAmountEnum.LOW },
        amountOut: BigInt(-1)
      };
      for (const feeAmount in FeeAmountEnum) {
        try {
          const amountOut = await this._getAmountByCurrentPrice(
            {
              blockchain,
              amount,
              tokenAddressFrom,
              tokenAddressTo,
              feeAmount: feeAmount as FeeAmountEnum
            },
            formNodeCall
          );
          this._logger.debug(`fee: ${FEE_AMOUNT[feeAmount as FeeAmountEnum]} amountOut: ${amountOut} `);
          if (amountOut >= maxEstimateAmount) {
            maxEstimateAmount = amountOut;
            result = {
              serviceData: { fee: feeAmount as FeeAmountEnum },
              amountOut
            };
          }
        } catch (err) {
          this._logger.warn(`quoteExactInputSingle error: ${err.message} `);
        }
      }
      return result;
    }
  }

  /**
   * Method, use for get estimate amount.
   * @param dto Dex get estimate amount dto.
   * @returns Object of DexEstimateAmountOutType.
   * @link More information on
   * https://docs.uniswap.org/protocol/reference/periphery/interfaces/IQuoter#quoteexactinput.
   */
  async getEstimateAmount(dto: DexGetEstimateAmountDto, formNodeCall = false): Promise<DexEstimateAmountOutType> {
    this._logger.debug(`method: getEstimateAmount`);
    if (formNodeCall) {
      return await this._getEstimateAmountFromNodeCall(dto);
    }
    return await this._getEstimateAmountFromRate(dto);
  }

  private async _getAmountByCurrentPrice(
    dto: {
      blockchain: BlockchainEnum;
      amount: string;
      tokenAddressFrom: string;
      tokenAddressTo: string;
      feeAmount: FeeAmountEnum;
    },
    formNodeCall = false
  ): Promise<bigint> {
    this._logger.debug(`method : _getAmountByCurrentPrice`);
    this._logger.debug(`dto: ${JSON.stringify(dto)}`);
    const { blockchain, feeAmount, tokenAddressFrom, tokenAddressTo, amount: amountDesired } = dto;

    const amount = new BigNumber(amountDesired);

    const pool = formNodeCall
      ? await this._getPool(blockchain, tokenAddressFrom, tokenAddressTo, feeAmount)
      : await this._getPool(blockchain, tokenAddressFrom, tokenAddressTo, feeAmount);
    const currentPrice0 = new BigNumber(pool.priceOf(pool.token0).toSignificant(6));
    const currentPrice1 = new BigNumber(pool.priceOf(pool.token1).toSignificant(6));
    const amountOut = tokenAddressFrom !== pool.token0.address ? amount.multipliedBy(currentPrice1) : amount.multipliedBy(currentPrice0);
    return BigInt(amountOut.toFixed(0));
  }

  private async _getEstimateAmountFromNodeCall(dto: DexGetEstimateAmountDto): Promise<DexEstimateAmountOutType> {
    const {
      blockchain,
      swapData: { amount, tokenAddressFrom, tokenAddressTo },
      feeAmount
    } = dto;
    this._logger.debug(`method: getEstimateAmountFromNodeCall`);
    this._logger.debug(`dto: ${JSON.stringify(dto)} `);

    const result = await this._getAmountOutForFee({
      blockchain,
      amount,
      tokenFrom: tokenAddressFrom,
      tokenTo: tokenAddressTo,
      feeAmount
    });
    return {
      serviceData: {
        fee: result.fee,
        poolAddress: result.poolAddress
      },
      amountOut: result.amountOut
    };
  }

  private async _getEstimateAmountFromRate(dto: DexGetEstimateAmountDto): Promise<DexEstimateAmountOutType> {
    return await this._getEstimateAmountFromNodeCall(dto);
  }

  /**
   * Method, use for get max amountOut for any fee.
   * @param withCommission
   * @param args Argument for get amount.
   * @returns Max amountOut and fee.
   */
  private async _getAmountOutForFee({
    ...args
  }: {
    blockchain: BlockchainEnum;
    amount: string;
    tokenFrom: string;
    tokenTo: string;
    feeAmount?: FeeAmountEnum;
    withCommission?: boolean;
  }): Promise<AmountOutMaxType> {
    this._logger.debug('method: _getAmountOutForFee');
    const { blockchain, amount, tokenFrom, tokenTo, feeAmount } = args;
    if (feeAmount) {
      const { amountOut, poolAddress } = await this._getAmountOutMax({
        blockchain,
        amount,
        tokenFrom,
        tokenTo,
        feeAmount
      });

      return {
        amountOut,
        poolAddress,
        fee: feeAmount
      };
    } else {
      let maxEstimateAmount = BigInt(-1);
      let result: Record<string, unknown> = {
        amountOut: BigInt(-1)
      };
      for (const feeAmount in FeeAmountEnum) {
        try {
          const { amountOut, poolAddress } = await this._getAmountOutMax({
            blockchain,
            amount,
            tokenFrom,
            tokenTo,
            feeAmount: feeAmount as FeeAmountEnum
          });

          this._logger.debug(`fee: ${FEE_AMOUNT[feeAmount as FeeAmountEnum]} amountOut: ${amountOut} `);
          if (amountOut >= maxEstimateAmount) {
            maxEstimateAmount = amountOut;
            result = {
              amountOut,
              poolAddress,
              fee: feeAmount as FeeAmountEnum
            };
          }
        } catch (err) {
          this._logger.warn(`quoteExactInputSingle error: ${err.message} `);
        }
      }
      return result as AmountOutMaxType;
    }
  }

  /**
   * Method, use for get amountOut after swap.
   * @param args Arguments for swap.
   * @returns Max amount after swap.
   */
  private async _getAmountOutMax(args: {
    blockchain: BlockchainEnum;
    amount: string;
    tokenFrom: string;
    tokenTo: string;
    feeAmount: FeeAmountEnum;
  }): Promise<{ amountOut: bigint; poolAddress: string }> {
    const { blockchain, amount, tokenFrom, tokenTo, feeAmount } = args;

    const { baseProvider, contractAggregator } = this._cryptoService.getProvider(blockchain);

    const quoterAddress = await contractAggregator.getAddressByName(UniswapV3ContractEnum.UniswapV3Quoter);
    const quoterContract = UniswapV3Quoter__factory.connect(quoterAddress, baseProvider);

    const amountOut = await quoterContract.quoteExactInputSingle.staticCall(
      tokenFrom,
      tokenTo,
      toBigNumberEthers(FEE_AMOUNT[feeAmount]),
      toBigNumberEthers(amount),
      toBigNumberEthers(0)
    );

    const factoryAddress = await contractAggregator.getAddressByName(UniswapV3ContractEnum.UniswapV3Factory);
    const factoryContract = UniswapV3Factory__factory.connect(factoryAddress, baseProvider);
    const poolAddress = await factoryContract.getPool(tokenFrom, tokenTo, FEE_AMOUNT[feeAmount]);

    return { amountOut, poolAddress };
  }

  private async _getPool(blockchain: BlockchainEnum, token0: string, token1: string, feeAmount: FeeAmountEnum): Promise<Pool> {
    const { baseProvider, contractAggregator } = this._cryptoService.getProvider(blockchain);

    const factoryAddress = await contractAggregator.getAddressByName(UniswapV3ContractEnum.UniswapV3Factory);

    const factoryContract = UniswapV3Factory__factory.connect(factoryAddress, baseProvider);

    const poolAddress = await factoryContract.getPool.staticCall(token0, token1, toBigNumberEthers(FEE_AMOUNT[feeAmount]));

    const poolContract = UniswapV3Pool__factory.connect(poolAddress, baseProvider);

    const token0address = await poolContract.token0.staticCall();
    const token1address = await poolContract.token1.staticCall();
    const token0Name = await contractAggregator.getNameByAddress(token0address);
    const token1Name = await contractAggregator.getNameByAddress(token1address);
    const CHAIN_ID = 1;
    const tokenA = new Token(
      CHAIN_ID,
      token0address,
      await contractAggregator.getDecimalTokenByAddress(token0address.toLowerCase()),
      token0Name
    );
    const tokenB = new Token(
      CHAIN_ID,
      token1address,
      await contractAggregator.getDecimalTokenByAddress(token1address.toLowerCase()),
      token1Name
    );
    const liquidity = await poolContract.liquidity.staticCall();
    const { tick, sqrtPriceX96 } = await poolContract.slot0.staticCall();
    const fee = Number(await poolContract.fee.staticCall());

    if (!Object.values(FeeAmount).includes(fee)) {
      throw new Error(`Fee ${fee} not exists in FeeAmount enum`);
    }
    return new Pool(tokenA, tokenB, fee, sqrtPriceX96.toString(), liquidity.toString(), Number(tick));
  }
}
