import { registerEnumType } from '@nestjs/graphql'

export enum FeeAmountEnum {
    LOWEST = 'LOWEST',
    LOW = 'LOW',
    MEDIUM = 'MEDIUM',
    HIGH = 'HIGH',
}

registerEnumType(FeeAmountEnum, {
    name: 'FeeAmountEnum',
})
