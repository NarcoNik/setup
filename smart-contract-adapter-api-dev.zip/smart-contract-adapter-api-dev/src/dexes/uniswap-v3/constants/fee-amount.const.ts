import { FeeAmountEnum } from '../enums/fee-amount.enum'

export const FEE_AMOUNT: { [key in FeeAmountEnum]: number } = {
    LOWEST: 100,
    LOW: 500,
    MEDIUM: 3000,
    HIGH: 10000,
}
