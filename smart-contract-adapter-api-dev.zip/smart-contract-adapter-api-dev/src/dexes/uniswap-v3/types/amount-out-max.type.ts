import { FeeAmountEnum } from '../enums/fee-amount.enum'

export type AmountOutMaxType = {
    amountOut: bigint
    fee: FeeAmountEnum
    poolAddress: string
}
