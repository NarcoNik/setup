import { FeeAmountEnum } from '../enums/fee-amount.enum'

export type UniswapV3ServiceData = {
    fee: FeeAmountEnum
}
