import { FeeAmountEnum } from '../enums/fee-amount.enum'

export type UniswapV3ServiceSwapData = {
    poolAddress: string
    fee: FeeAmountEnum
}
