import { Module } from '@nestjs/common'
import { ConfigModule } from '@nestjs/config'
import { UniswapV3DexService } from './uniswap-v3-dex.service'
import { CryptoModule } from '@defi-invest/common'

@Module({
    imports: [ConfigModule, CryptoModule],
    providers: [UniswapV3DexService],
    exports: [UniswapV3DexService],
})
export class UniswapV3DexModule {}
