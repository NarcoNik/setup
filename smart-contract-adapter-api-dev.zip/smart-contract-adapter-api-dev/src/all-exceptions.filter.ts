import { ArgumentsHost, Catch, Logger } from '@nestjs/common'
import { GqlExceptionFilter } from '@nestjs/graphql'
import { ResponseErrorCodesEnum, ResponseErrorType } from '@defi-invest/common'
import { ExceptionType } from './shared/exceptions/types/exception.type'

const logger = new Logger('AppBootstrap')

@Catch()
export class AllExceptionsFilter implements GqlExceptionFilter {
    catch(exception: ExceptionType, _host: ArgumentsHost): ResponseErrorType {
        try {
            const { message, code } =
                exception.getResponse() as { message: string, code: ResponseErrorCodesEnum }

            if (!code) {
                throw new Error(message)
            }

            return {
                message,
                code,
            }
        } catch (error) {
            if (exception.stack?.indexOf('validation') !== -1) {
                return {
                    message: `${error}`,
                    code: ResponseErrorCodesEnum.VALIDATION_ERROR,
                    // values: []
                }
            } else if (exception.stack?.indexOf('MongoServerError') !== -1) {
                return {
                    message: `${exception}`,
                    code: ResponseErrorCodesEnum.MONGO_ERROR,
                    // values: []
                }
            }

            return {
                message: `${exception}`,
                code: ResponseErrorCodesEnum.UNEXPECTED_ERROR,
                // values: []
            }
        } finally {
            logger.error(exception, exception.stack)
        }
    }
}