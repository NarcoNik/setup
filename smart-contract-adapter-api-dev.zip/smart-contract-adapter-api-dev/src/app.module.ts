import { ApolloFederationDriverAsyncConfig } from '@nestjs/apollo';
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { GraphQLModule } from '@nestjs/graphql';
import { graphQLConfig } from './config/graphql.config';
import { ExchangeApiModule } from './exchange-api/exchange-api.module';
import { CryptoModule } from '@defi-invest/common';
import { config } from './config/config';
// import { MongooseModule } from '@nestjs/mongoose';
// import { mongooseConfig } from './config/mongoose.config';

@Module({
  imports: [
    ConfigModule.forRoot(config),
    GraphQLModule.forRootAsync<ApolloFederationDriverAsyncConfig>(graphQLConfig),
    CryptoModule,
    ExchangeApiModule
    // MongooseModule.forRootAsync(mongooseConfig)
  ]
})
export class AppModule {}
