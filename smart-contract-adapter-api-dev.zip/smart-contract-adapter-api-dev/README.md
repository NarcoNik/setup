# smart-contract-adapter-api

## smart-contract-admin module

### queries

```shell
query getServiceCommission {
  getServiceCommission(
    input: {
      blockchain: ETH
      address: "0xAf4fD6117448B5FE1727412114cdF3450DEbc9e0"
    }
  ) {
    ... on ServiceCommissionObjectType {
      isActive
      amount
    }
    ... on ResponseErrorType {
      message
      code
      values
    }
  }
}

query getOwnerCommission {
  getOwnerCommission(
    input: {
      blockchain: ETH
      address: "0xAf4fD6117448B5FE1727412114cdF3450DEbc9e0"
    }
  ) {
    ... on ServiceCommissionObjectType {
      isActive
      amount
    }
    ... on ResponseErrorType {
      message
      code
      values
    }
  }
}

query getAmountServiceCommission {
  getAmountServiceCommission(
    input: {
      blockchain: ETH
      token: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2"
      serviceAddress: "0xAf4fD6117448B5FE1727412114cdF3450DEbc9e0"
      isNativeToken: true
    }
  ) {
    ... on CountOfContractTokenObjectType{
      tokenCount
    }
    ... on ResponseErrorType {
      message
      code
      values
    }
  }
}

query getAmountOwnerCommission {
  getAmountOwnerCommission(
    input: { blockchain: ETH, token: "", isNativeToken: true }
  ) {
    ... on CountOfContractTokenObjectType{
      tokenCount
    }
    ... on ResponseErrorType {
      message
      code
      values
    }
  }
}

query changeBits {
  changeBits(
    input: { blockchain: ETH, defiId: "1", bitIds: ["0"], values: [true] }
  ) {
    ... on NewMethodsActivityObjectType{
      newMethodsActivity
    }
    ... on ResponseErrorType {
      message
      code
      values
    }
  }
}

query getDefis {
  getDefis(input: { blockchain: ETH }) {
    ... on DefisObjectType {
      defis {
        nameId
        methodsActive
        addresses
        isActive
      }
    }
    ... on ResponseErrorType {
      message
      code
      values
    }
  }
}

query getPools {
  getPools(input: { blockchain: ETH }) {
    ... on PoolsObjectType {
      pools {
        defiId
        poolAddress
        isActive
      }
    }
    ... on ResponseErrorType {
      message
      code
      values
    }
  }
}

query getPoolsForDefi {
  getPoolsForDefi(input: { blockchain: ETH, defiId: "0" }) {
    ... on PoolsObjectType {
      pools {
        defiId
        poolAddress
        isActive
      }
    }
    ... on ResponseErrorType {
      message
      code
      values
    }
  }
}

query getStrategies {
  getStrategies(input: { blockchain: ETH }) {
    ... on StrategiesObjectType {
      strategies {
        nameId
        isActive
      }
    }
    ... on ResponseErrorType {
      message
      code
      values
    }
  }
}

query getDLP {
  getDLP(input: { blockchain: ETH }) {
    ... on DlpAddressObjectType{
      dlpAddress
    }
    ... on ResponseErrorType {
      message
      code
      values
    }
  }
}

query getDLPToLP {
  getDLPToLP(input: { blockchain: ETH, amountDLP: "100", idPublicDLP: "1" }) {
    ... on LpTokenCountObjectType{
      lpTokenCount
    }
    ... on ResponseErrorType {
      message
      code
      values
    }
  }
}

query getInfoDLP {
  getInfoDLP(input: { blockchain: ETH, dlpId: "1" }) {
    ... on DlpInfoObjectType {
      strategyId
      poolId
      lpCount
      extraFullArgs
    }
    ... on ResponseErrorType {
      message
      code
      values
    }
  }
}

query getInternalBalance {
  getInternalBalance(
    input: {
      blockchain: ETH
      dlpId: "1"
      serviceAddress: "0xAf4fD6117448B5FE1727412114cdF3450DEbc9e0"
      realOwnerAddress: "0xAf4fD6117448B5FE1727412114cdF3450DEbc9e0"
    }
  ) {
    ... on UserDlpTokenCountObjectType{
      userDlpTokenCount
    }
    ... on ResponseErrorType {
      message
      code
      values
    }
  }
}

```

### mutations

```shell

mutation changeServiceCommission {
  changeServiceCommission(
    input: {
      blockchain: ETH
      address: "0xAf4fD6117448B5FE1727412114cdF3450DEbc9e0"
      newCommission: { isActive: true, amount: "1" }
    }
  ) {
    ... on BooleanValue {
      result
    }
    ... on ResponseErrorType {
      message
      code
      values
    }
  }
}

mutation changeOwnerCommission {
  changeOwnerCommission(
    input: {
      blockchain: ETH
      address: "0xAf4fD6117448B5FE1727412114cdF3450DEbc9e0"
      newCommission: { isActive: true, amount: "1" }
    }
  ) {
    ... on BooleanValue {
      result
    }
    ... on ResponseErrorType {
      message
      code
      values
    }
  }
}

mutation withdrawServiceCommission {
  withdrawServiceCommission(
    input: {
      blockchain: ETH
      token: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2"
      amount: "0"
      isNativeToken: true
    }
  ) {
    ... on BooleanValue {
      result
    }
    ... on ResponseErrorType {
      message
      code
      values
    }
  }
}

mutation withdrawOwnerCommission {
  withdrawOwnerCommission(
    input: {
      blockchain: ETH
      token: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2"
      amount: "0"
      isNativeToken: true
      user: "0xAf4fD6117448B5FE1727412114cdF3450DEbc9e0"
    }
  ) {
    ... on BooleanValue {
      result
    }
    ... on ResponseErrorType {
      message
      code
      values
    }
  }
}

mutation changeMethodsActive {
  changeMethodsActive(
    input: { blockchain: ETH, defiId: "1", newMethodsActive: "1" }
  ) {
    ... on BooleanValue {
      result
    }
    ... on ResponseErrorType {
      message
      code
      values
    }
  }
}

mutation requestOwnershipTransfer {
  requestOwnershipTransfer(
    input: { blockchain: ETH, newOwnerAddress: "" }
  ) {
    ... on BooleanValue {
      result
    }
    ... on ResponseErrorType {
      message
      code
      values
    }
  }
}

mutation approveOwnershipTransfer {
  approveOwnershipTransfer(
    input: { blockchain: ETH }
  ) {
    ... on BooleanValue {
      result
    }
    ... on ResponseErrorType {
      message
      code
      values
    }
  }
}

mutation addDefi {
  addDefi(
    input: {
      blockchain: ETH
      nameId: "10"
      newMethodsActive: "7"
      addresses: ["0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D"]
      isActivity: true
    }
  ) {
    ... on BooleanValue {
      result
    }
    ... on ResponseErrorType {
      message
      code
      values
    }
  }
}

mutation addStrategy {
  addStrategy(
    input: {
      blockchain: ETH
      isActivity: true
    }
  ) {
    ... on BooleanValue {
      result
    }
    ... on ResponseErrorType {
      message
      code
      values
    }
  }
}

mutation addPool {
  addPool(
    input: {
      blockchain: ETH
      defiId: "10"
      address: "0xE592427A0AEce92De3Edee1F18E0157C05861564"
      isPoolActivity: true
    }
  ) {
    ... on BooleanValue {
      result
    }
    ... on ResponseErrorType {
      message
      code
      values
    }
  }
}

mutation addDlp {
  addDlp(
    input: {
      blockchain: ETH
      strategyId: "1"
      poolId: "0"
      extraArgs: ""
    }
  ) {
    ... on BooleanValue {
      result
    }
    ... on ResponseErrorType {
      message
      code
      values
    }
  }
}

mutation transferDepositService {
  transferDepositService(
    input: {
      blockchain: ETH
      dlpId: "1"
      dlpAmount: "0"
      addressFrom: "0xAf4fD6117448B5FE1727412114cdF3450DEbc9e0"
      addressTo: "0xAf4fD6117448B5FE1727412114cdF3450DEbc9e0"
    }
  ) {
    ... on BooleanValue {
      result
    }
    ... on ResponseErrorType {
      message
      code
      values
    }
  }
}

```

# Smart Contract User Operations

## Invest Forward

### Пример инвестирования в два пула Uniswap v2 и Uniswap v3

1. Для Uniswap v3 сперва нужно получить extraArgs

```graphql
query getExtraArgs {
    getExtraArgs(
        input: {
            defi: UNISWAPV3
            poolAddress: "0x88e6a0c2ddd26feeb64f039a2c41296fcb3f5640"
        }
    )
}
```

2. Теперь нужно узнать оптимальные значения токенов для пула.
   Вводим желаемое количество одного токена.

```graphql
query UNISWAPV2_USDT {
    getInvestOptimalAmounts(
        input: {
            defi: UNISWAPV2
            poolAddress: "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852"
            token: {
                tokenAddress: "0xdac17f958d2ee523a2206206994597c13d831ec7"
                tokenAmount: "1000000000"
            }
        }
    ) {
        tokens {
            tokenAddress
            tokenAmount
        }
    }
}

query UNISWAPV3_USDC {
    getInvestOptimalAmounts(
        input: {
            defi: UNISWAPV3
            poolAddress: "0x88e6a0c2ddd26feeb64f039a2c41296fcb3f5640"
            token: {
                tokenAddress: "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48"
                tokenAmount: "1000000000"
            }
            extraArgs: "{\"priceLower\":\"0.000205\",\"priceUpper\":\"0.001841\"}"
        }
    ) {
        tokens {
            tokenAddress
            tokenAmount
        }
    }
}
```

3. Заранее создадим dlp токены, пулы и стратегии в смарт контракте
   В tokensTransferInfo нужно суммировать все инвестируемые токены в пулах.
   У serviceWallet должны быть необходимые активы.

```graphql
query investForward_UNIV3 {
    investForward(
        input: {
            blockchain: ETH
            userWallet: "0x70997970C51812dc3A010C7d01b50e0d17dc79C8"
            serviceWallet: "0x70997970C51812dc3A010C7d01b50e0d17dc79C8"
            strategyId: 0
            strategyName: LOW
            tokensTransferInfo: [
                {
                    tokenAddress: "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48"
                    tokenAmount: "1000000000"
                }
                {
                    tokenAddress: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"
                    tokenAmount: "1261731469918760655"
                }
                {
                    tokenAddress: "0xdac17f958d2ee523a2206206994597c13d831ec7"
                    tokenAmount: "1000000000"
                }
            ]
            investProductsInfo: {
                poolList: [
                    {
                        poolId: 22
                        defiName: UNISWAPV3
                        poolAddress: "0x88e6a0c2ddd26feeb64f039a2c41296fcb3f5640"
                        dlpIds: [2]
                        extraArgs: "{\"priceLower\":\"0.000205\",\"priceUpper\":\"0.001841\"}"
                        investTokens: [
                            {
                                tokenAddress: "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48"
                                tokenAmount: "1000000000"
                            }
                            {
                                tokenAddress: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"
                                tokenAmount: "612304453142424722"
                            }
                        ]
                    }
                    {
                        poolId: 2
                        defiName: UNISWAPV2
                        poolAddress: "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852"
                        dlpIds: [1]
                        extraArgs: ""
                        investTokens: [
                            {
                                tokenAddress: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"
                                tokenAmount: "649427016776335933"
                            }
                            {
                                tokenAddress: "0xdac17f958d2ee523a2206206994597c13d831ec7"
                                tokenAmount: "1000000000"
                            }
                        ]
                    }
                ]
            }
        }
    ) {
        data
        gasLimit
        value
        maxPriorityFeePerGas
        maxFeePerGas
        to
    }
}
```

4. Вывод средств. Количество ликвидности в пуле, должно соотносится с removePercent, относительно общей ликвидности пользователя в пуле.

```graphql
query {
    withdrawForward(
        input: {
            blockchain: ETH
            removePercent: FULL
            userWallet: "0x70997970C51812dc3A010C7d01b50e0d17dc79C8"
            serviceWallet: "0x70997970C51812dc3A010C7d01b50e0d17dc79C8"
            strategyId: 0
            withdrawTokenAddress: "0x0000000000000000000000000000000000000000"
            withdrawProductsList: [
                {
                    poolId: 2
                    defiName: UNISWAPV2
                    poolAddress: "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852"
                    liquidity: "10782126102355"
                    extraArgs: ""
                    dlpIds: [1]
                }
                {
                    poolId: 22
                    defiName: UNISWAPV3
                    poolAddress: "0x88e6a0c2ddd26feeb64f039a2c41296fcb3f5640"
                    liquidity: "58593576082614"
                    extraArgs: "{\"priceLower\":\"0.000205\",\"priceUpper\":\"0.001841\"}"
                    dlpIds: [2]
                }
            ]
        }
    ) {
        gasLimit
        maxPriorityFeePerGas
        maxFeePerGas
        value
        to
        data
    }
}
```

# Exchange module

### Посчитать обмены с помощью current price

```graphql
query exchangeByCurrentPrice {
    exchangeByCurrentPrice(
        input: {
            blockchain: ETH
            from: "0xdAC17F958D2ee523a2206206994597C13D831ec7"
            to: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48"
            amount: "1000000"
            #dexName: UNISWAPV3,
            #feeAmount: MEDIUM
            formNodeCall: false
        }
    ) {
        ... on GetAmountOutObjectType {
            amountOut
        }

        ... on ResponseErrorType {
            message
            code
            values
        }
    }
}
```

## Расчет необходимых данных для инвеста и свапа токена

Методы:

1. getTokenAmountsForInvest
2. getTokenPercentsForSwap
3. getTokenPercentsForInvest
4. getApproximateAmountsForInvest
5. getApproximateAmountsForSwap

### Случай 1. Инвестируется один токен. Необходимо рассчитать его свапы в другие токены и инвесты получившихся токенов.

1. Получение процентов инвеста токена

```graphql
query three {
    getTokenPercentsForInvest(
        input: {
            pools: [
                {
                    poolAddress: "00001"
                    poolWeightInPercent: "20.000002"
                    tokensRatio: [
                        {
                            tokenAddress: "0xdAC17F958D2ee523a2206206994597C13D831ec7"
                            percent: "80.000001"
                        }
                        {
                            tokenAddress: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48"
                            percent: "19.999999"
                        }
                    ]
                }
                {
                    poolAddress: "00002"
                    poolWeightInPercent: "30.999990"
                    tokensRatio: [
                        {
                            tokenAddress: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2"
                            percent: "40.000001"
                        }
                        {
                            tokenAddress: "0xdAC17F958D2ee523a2206206994597C13D831ec7"
                            percent: "59.999999"
                        }
                    ]
                }
                {
                    poolAddress: "00003"
                    poolWeightInPercent: "49.000008"
                    tokensRatio: [
                        {
                            tokenAddress: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2"
                            percent: "70.000001"
                        }
                        {
                            tokenAddress: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48"
                            percent: "29.999999"
                        }
                    ]
                }
            ]
        }
    ) {
        ... on TokensPercentForInvestObjectType {
            pools {
                poolAddress
                tokens {
                    tokenAddress
                    percent
                }
            }
        }

        ... on ResponseErrorType {
            message
            code
            values
        }
    }
}
```

Передаем массив пулов, куда следует инвестить:
tokenInPercent - процент входного токена на данный пул
tokensRatio - соотношение токенов в данном пуле

Результат:
Посчитаные проценты инвестов

2. Получение процентов свапов токена

```graphql
query two {
    getTokenAmountPercents(
        input: {
            pools: [
                {
                    poolAddress: "00001"
                    poolWeightInPercent: "20.000002"
                    tokensRatio: [
                        {
                            tokenAddress: "0xdAC17F958D2ee523a2206206994597C13D831ec7"
                            percent: "80.000001"
                        }
                        {
                            tokenAddress: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48"
                            percent: "19.999999"
                        }
                    ]
                }
                {
                    poolAddress: "00002"
                    poolWeightInPercent: "30.999990"
                    tokensRatio: [
                        {
                            tokenAddress: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2"
                            percent: "40.000001"
                        }
                        {
                            tokenAddress: "0xdAC17F958D2ee523a2206206994597C13D831ec7"
                            percent: "59.999999"
                        }
                    ]
                }
                {
                    poolAddress: "00003"
                    poolWeightInPercent: "49.000008"
                    tokensRatio: [
                        {
                            tokenAddress: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2"
                            percent: "70.000001"
                        }
                        {
                            tokenAddress: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48"
                            percent: "29.999999"
                        }
                    ]
                }
            ]
        }
    ) {
        ... on TokensPercentAmountObjectType {
            tokensPercent {
                tokenAddress
                percent
                count
            }
        }

        ... on ResponseErrorType {
            message
            code
            values
        }
    }
}
```

Передаем массив пулов, куда следует инвестить:
tokenInPercent - процент входного токена на данный пул
tokensRatio - соотношение токенов в данном пуле

Результат:
Посчитаные проценты свапов

3. Теперь нужно узнать примерные значения после свапа токена.

```graphql
query five {
    getApproximateAmountsForSwap(
        input: {
            blockchain: ETH
            tokenInput: {
                tokenAddress: "0xdac17f958d2ee523a2206206994597c13d831ec7"
                tokenAmount: "100000000"
            }
            tokenPercent: [
                {
                    tokenAddress: "0xdac17f958d2ee523a2206206994597c13d831ec7"
                    percent: "34.59999549000012"
                    count: 2
                }
                {
                    tokenAddress: "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48"
                    percent: "18.7000021099999"
                    count: 2
                }
                {
                    tokenAddress: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"
                    percent: "46.70000239999998"
                    count: 2
                }
            ]
        }
    ) {
        ... on ApproximateAmountsForSwapObjectType {
            swapData
            tokensAmount {
                tokenAddress
                count
                amountVirtual
            }
        }

        ... on ResponseErrorType {
            message
            code
            values
        }
    }
}
```

Указываем:
блокчейн, в котором нужно посчитать свапы,
входной токен
массив свапов, полученные на 2 шаге

Результат:
swapData - дата свапа для смарт-контракта
tokensAmount - массив токенов, которые получатся в результате свапа (потребуется на след шаге)

4. Теперь нужно узнать примерные значения для инвеста.

```graphql
query four {
    getApproximateAmountsForInvest(
        input: {
            pools: [
                {
                    poolAddress: "00001"
                    tokensPercent: [
                        {
                            tokenAddress: "0xdAC17F958D2ee523a2206206994597C13D831ec7"
                            percent: "46242786"
                        }
                        {
                            tokenAddress: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48"
                            percent: "21390373"
                        }
                    ]
                }
                {
                    poolAddress: "00002"
                    tokensPercent: [
                        {
                            tokenAddress: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2"
                            percent: "26552453"
                        }
                        {
                            tokenAddress: "0xdAC17F958D2ee523a2206206994597C13D831ec7"
                            percent: "53757214"
                        }
                    ]
                }
                {
                    poolAddress: "00003"
                    tokensPercent: [
                        {
                            tokenAddress: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2"
                            percent: "73447547"
                        }
                        {
                            tokenAddress: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48"
                            percent: "78609627"
                        }
                    ]
                }
            ]
            tokens: [
                {
                    tokenAddress: "0xdac17f958d2ee523a2206206994597c13d831ec7"
                    count: 2
                    amountVirtual: "34599995"
                }
                {
                    tokenAddress: "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48"
                    count: 2
                    amountVirtual: "18700149"
                }
                {
                    tokenAddress: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"
                    count: 2
                    amountVirtual: "22616689747715485"
                }
            ]
        }
    ) {
        ... on ApproximateAmountsForInvestObjectType {
            pools {
                poolAddress
                tokens {
                    tokenAddress
                    percent
                    amountVirtual
                }
            }
        }
        ... on ResponseErrorType {
            message
            code
            values
        }
    }
}
```

Указываем:
массив пулов из 1 первого шага
массив токенов из 3 шага

Результат:
пулы с процентами и примерными значениями токенов

### Случай 2. Инвестируется несколько токенов без свапов. Необходимо на основе одного из токенов рассчитать количество других токенов.

1. Получение процентов инвеста токена

```graphql
query three {
    getTokenPercentsForInvest(
        input: {
            pools: [
                {
                    poolAddress: "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852"
                    poolWeightInPercent: "50.000001"
                    tokensRatio: [
                        {
                            tokenAddress: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"
                            percent: "50.000001"
                        }
                        {
                            tokenAddress: "0xdac17f958d2ee523a2206206994597c13d831ec7"
                            percent: "49.999999"
                        }
                    ]
                }
                {
                    poolAddress: "0x88e6a0c2ddd26feeb64f039a2c41296fcb3f5640"
                    poolWeightInPercent: "49.999999"
                    tokensRatio: [
                        {
                            tokenAddress: "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48"
                            percent: "49.999999"
                        }
                        {
                            tokenAddress: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"
                            percent: "50.000001"
                        }
                    ]
                }
            ]
        }
    ) {
        ... on TokensPercentForInvestObjectType {
            pools {
                poolAddress
                tokens {
                    tokenAddress
                    percent
                }
            }
        }

        ... on ResponseErrorType {
            message
            code
            values
        }
    }
}
```

Передаем массив пулов, куда следует инвестить:
tokenInPercent - процент входного токена на данный пул
tokensRatio - соотношение токенов в данном пуле

Результат:
Посчитаные проценты инвестов

2. Получение количества каждого из токена

```graphql
query one {
    getTokenAmountsForInvest(
        input: {
            blockchain: ETH
            tokenInput: {
                tokenAddress: "0xdac17f958d2ee523a2206206994597c13d831ec7"
                tokenAmount: "100000000"
            }
            pools: [
                {
                    poolAddress: "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852"
                    poolWeightInPercent: "50.000001"
                    tokensRatio: [
                        {
                            tokenAddress: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"
                            percent: "50.000001"
                        }
                        {
                            tokenAddress: "0xdac17f958d2ee523a2206206994597c13d831ec7"
                            percent: "49.999999"
                        }
                    ]
                }
                {
                    poolAddress: "0x88e6a0c2ddd26feeb64f039a2c41296fcb3f5640"
                    poolWeightInPercent: "49.999999"
                    tokensRatio: [
                        {
                            tokenAddress: "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48"
                            percent: "49.999999"
                        }
                        {
                            tokenAddress: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"
                            percent: "50.000001"
                        }
                    ]
                }
            ]
        }
    ) {
        ... on TokenAmountsForInvestObjectType {
            tokensAmount {
                tokenAddress
                count
                amountVirtual
            }
        }

        ... on ResponseErrorType {
            message
            code
            values
        }
    }
}
```

Передаем вхоной токен,  
Передаем массив пулов, куда следует инвестить:  
tokenInPercent - процент входного токена на данный пул  
tokensRatio - соотношение токенов в данном пуле

Результат:
Посчитаные amount токенов

3. Теперь нужно узнать примерные значения для инвеста.

```graphql
query four {
    getApproximateAmountsForInvest(
        input: {
            pools: [
                {
                    poolAddress: "0x0d4a11d5eeaac28ec3f61d100daf4d40471f1852"
                    tokensPercent: [
                        {
                            tokenAddress: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"
                            percent: "50000001"
                        }
                        {
                            tokenAddress: "0xdac17f958d2ee523a2206206994597c13d831ec7"
                            percent: "100000000"
                        }
                    ]
                }
                {
                    poolAddress: "0x88e6a0c2ddd26feeb64f039a2c41296fcb3f5640"
                    tokensPercent: [
                        {
                            tokenAddress: "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48"
                            percent: "100000000"
                        }
                        {
                            tokenAddress: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"
                            percent: "49999999"
                        }
                    ]
                }
            ]
            tokens: [
                {
                    tokenAddress: "0xdac17f958d2ee523a2206206994597c13d831ec7"
                    count: 1
                    amountVirtual: "250000000"
                }
                {
                    tokenAddress: "0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"
                    count: 2
                    amountVirtual: "242145940175512859"
                }
                {
                    tokenAddress: "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48"
                    count: 1
                    amountVirtual: "250001972"
                }
            ]
        }
    ) {
        ... on ApproximateAmountsForInvestObjectType {
            pools {
                poolAddress
                tokens {
                    tokenAddress
                    percent
                    amountVirtual
                }
            }
        }
        ... on ResponseErrorType {
            message
            code
            values
        }
    }
}
```

Указываем:
массив пулов из 1 первого шага
массив токенов из 2 шага

Результат:
пулы с процентами и примерными значениями токенов

### Получить дату для свапа после вывода

```graphql
query six {
    getSwapDataAfterRemove(
        input: {
            blockchain: ETH
            tokenSwapToAddress: "0xdac17f958d2ee523a2206206994597c13d831ec7"
            pools: [
                {
                    poolAddress: "0001"
                    poolTokens: [
                        {
                            tokenAddress: "0xdAC17F958D2ee523a2206206994597C13D831ec7"
                            tokenAmount: "16000002"
                        }
                        {
                            tokenAddress: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48"
                            tokenAmount: "4000032"
                        }
                    ]
                }
                {
                    poolAddress: "0002"
                    poolTokens: [
                        {
                            tokenAddress: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2"
                            tokenAmount: "6005285915417973"
                        }
                        {
                            tokenAddress: "0xdAC17F958D2ee523a2206206994597C13D831ec7"
                            tokenAmount: "18599993"
                        }
                    ]
                }
                {
                    poolAddress: "0003"
                    poolTokens: [
                        {
                            tokenAddress: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2"
                            tokenAmount: "16611403832297512"
                        }
                        {
                            tokenAddress: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48"
                            tokenAmount: "14700117"
                        }
                    ]
                }
            ]
        }
    ) {
        ... on SwapDataAfterRemoveObjectType {
            swapData
            virtualAmount
        }

        ... on ResponseErrorType {
            message
            code
            values
        }
    }
}
```

Указываем:
блокчейн, в котором нужно посчитать свапы,
выходной токен
пулов и их токены, полученные после виртуального вывода

Результат:
swapData - дата свапа для смарт-контракта
virtualAmount - примерное количество выхожного токена, которое получится после свапа

$$
$$
