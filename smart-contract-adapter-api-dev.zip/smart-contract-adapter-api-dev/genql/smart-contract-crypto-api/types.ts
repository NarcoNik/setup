export default {
    "scalars": [
        1,
        2,
        4,
        5,
        6,
        7,
        8
    ],
    "types": {
        "ResponseErrorType": {
            "message": [
                1
            ],
            "code": [
                2
            ],
            "values": [
                1
            ],
            "__typename": [
                1
            ]
        },
        "String": {},
        "ResponseErrorCodesEnum": {},
        "ScoredProductObjectType": {
            "blockchain": [
                6
            ],
            "poolId": [
                4
            ],
            "poolAddress": [
                1
            ],
            "defiId": [
                4
            ],
            "defiName": [
                7
            ],
            "strategyId": [
                4
            ],
            "strategyName": [
                8
            ],
            "rate": [
                4
            ],
            "active": [
                5
            ],
            "__typename": [
                1
            ]
        },
        "Float": {},
        "Boolean": {},
        "BlockchainEnum": {},
        "DefiEnum": {},
        "InvestStrategyEnum": {},
        "Query": {
            "getUnsignedTransaction": [
                10,
                {
                    "input": [
                        12,
                        "SendTransactionInputType!"
                    ]
                }
            ],
            "__typename": [
                1
            ]
        },
        "UnsignedTransactionObjectUnionType": {
            "on_UnsignedTransactionObjectType": [
                11
            ],
            "on_ResponseErrorType": [
                0
            ],
            "__typename": [
                1
            ]
        },
        "UnsignedTransactionObjectType": {
            "gasLimit": [
                1
            ],
            "maxPriorityFeePerGas": [
                1
            ],
            "maxFeePerGas": [
                1
            ],
            "value": [
                1
            ],
            "to": [
                1
            ],
            "data": [
                1
            ],
            "__typename": [
                1
            ]
        },
        "SendTransactionInputType": {
            "blockchain": [
                6
            ],
            "data": [
                1
            ],
            "contractAddress": [
                1
            ],
            "value": [
                1
            ],
            "estimateGas": [
                1
            ],
            "__typename": [
                1
            ]
        },
        "Mutation": {
            "sendTransaction": [
                5,
                {
                    "input": [
                        12,
                        "SendTransactionInputType!"
                    ]
                }
            ],
            "sendUserTransaction": [
                1,
                {
                    "unsignedTransaction": [
                        14,
                        "UnsignedTransactionInputType!"
                    ],
                    "wallet": [
                        15,
                        "WalletInputType!"
                    ]
                }
            ],
            "__typename": [
                1
            ]
        },
        "UnsignedTransactionInputType": {
            "blockchain": [
                6
            ],
            "gasLimit": [
                1
            ],
            "maxPriorityFeePerGas": [
                1
            ],
            "maxFeePerGas": [
                1
            ],
            "value": [
                1
            ],
            "to": [
                1
            ],
            "data": [
                1
            ],
            "__typename": [
                1
            ]
        },
        "WalletInputType": {
            "address": [
                1
            ],
            "privateKey": [
                1
            ],
            "__typename": [
                1
            ]
        }
    }
}