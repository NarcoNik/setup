// @ts-nocheck
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type Scalars = {
    String: string,
    Float: number,
    Boolean: boolean,
}

export interface ResponseErrorType {
    message: Scalars['String']
    code: ResponseErrorCodesEnum
    /** Dynamic values in message, for example - `Currency price ${amount} ${symbol} is less than min ${minInvestPrice} USDT`,values would be array [${amount}, ${symbol}, ${minInvestPrice}] in strict order */
    values: (Scalars['String'][] | null)
    __typename: 'ResponseErrorType'
}

export type ResponseErrorCodesEnum = 'EMPTY_FIELD' | 'UNEXPECTED_ERROR' | 'FOUND_MULTIPLE_DOCUMENTS' | 'DOCUMENT_NOT_FOUND' | 'DOCUMENTS_NOT_FOUND' | 'VALIDATION_ERROR' | 'MONGO_ERROR' | 'REDIS_ERROR'

export interface ScoredProductObjectType {
    blockchain: BlockchainEnum
    poolId: Scalars['Float']
    poolAddress: Scalars['String']
    defiId: Scalars['Float']
    defiName: DefiEnum
    strategyId: Scalars['Float']
    strategyName: InvestStrategyEnum
    rate: Scalars['Float']
    active: Scalars['Boolean']
    __typename: 'ScoredProductObjectType'
}

export type BlockchainEnum = 'ETH' | 'BNB'

export type DefiEnum = 'COMPOUND' | 'ALPHAHOMORAV2' | 'SUSHISWAP' | 'UNISWAPV2' | 'UNISWAPV3' | 'PANCAKESWAP' | 'TOPCORN' | 'ONEINCH'

export type InvestStrategyEnum = 'LOW' | 'MEDIUM' | 'HIGH'

export interface Query {
    getUnsignedTransaction: UnsignedTransactionObjectUnionType
    __typename: 'Query'
}

export type UnsignedTransactionObjectUnionType = (UnsignedTransactionObjectType | ResponseErrorType) & { __isUnion?: true }

export interface UnsignedTransactionObjectType {
    gasLimit: Scalars['String']
    maxPriorityFeePerGas: (Scalars['String'] | null)
    maxFeePerGas: (Scalars['String'] | null)
    value: Scalars['String']
    to: Scalars['String']
    data: Scalars['String']
    __typename: 'UnsignedTransactionObjectType'
}

export interface Mutation {
    sendTransaction: Scalars['Boolean']
    /** Only for tests */
    sendUserTransaction: Scalars['String']
    __typename: 'Mutation'
}

export interface ResponseErrorTypeGenqlSelection{
    message?: boolean | number
    code?: boolean | number
    /** Dynamic values in message, for example - `Currency price ${amount} ${symbol} is less than min ${minInvestPrice} USDT`,values would be array [${amount}, ${symbol}, ${minInvestPrice}] in strict order */
    values?: boolean | number
    __typename?: boolean | number
    __scalar?: boolean | number
}

export interface ScoredProductObjectTypeGenqlSelection{
    blockchain?: boolean | number
    poolId?: boolean | number
    poolAddress?: boolean | number
    defiId?: boolean | number
    defiName?: boolean | number
    strategyId?: boolean | number
    strategyName?: boolean | number
    rate?: boolean | number
    active?: boolean | number
    __typename?: boolean | number
    __scalar?: boolean | number
}

export interface QueryGenqlSelection{
    getUnsignedTransaction?: (UnsignedTransactionObjectUnionTypeGenqlSelection & { __args: {input: SendTransactionInputType} })
    __typename?: boolean | number
    __scalar?: boolean | number
}

export interface UnsignedTransactionObjectUnionTypeGenqlSelection{
    on_UnsignedTransactionObjectType?:UnsignedTransactionObjectTypeGenqlSelection,
    on_ResponseErrorType?:ResponseErrorTypeGenqlSelection,
    __typename?: boolean | number
}

export interface UnsignedTransactionObjectTypeGenqlSelection{
    gasLimit?: boolean | number
    maxPriorityFeePerGas?: boolean | number
    maxFeePerGas?: boolean | number
    value?: boolean | number
    to?: boolean | number
    data?: boolean | number
    __typename?: boolean | number
    __scalar?: boolean | number
}

export interface SendTransactionInputType {blockchain: BlockchainEnum,data: Scalars['String'],contractAddress: Scalars['String'],
/** wei value */
value: Scalars['String'],
/** wei estimateGas */
estimateGas: Scalars['String']}

export interface MutationGenqlSelection{
    sendTransaction?: { __args: {input: SendTransactionInputType} }
    /** Only for tests */
    sendUserTransaction?: { __args: {unsignedTransaction: UnsignedTransactionInputType, wallet: WalletInputType} }
    __typename?: boolean | number
    __scalar?: boolean | number
}

export interface UnsignedTransactionInputType {blockchain: BlockchainEnum,gasLimit: Scalars['String'],maxPriorityFeePerGas?: (Scalars['String'] | null),maxFeePerGas?: (Scalars['String'] | null),value: Scalars['String'],to: Scalars['String'],data: Scalars['String']}

export interface WalletInputType {address: Scalars['String'],privateKey: Scalars['String']}


    const ResponseErrorType_possibleTypes: string[] = ['ResponseErrorType']
    export const isResponseErrorType = (obj?: { __typename?: any } | null): obj is ResponseErrorType => {
      if (!obj?.__typename) throw new Error('__typename is missing in "isResponseErrorType"')
      return ResponseErrorType_possibleTypes.includes(obj.__typename)
    }
    


    const ScoredProductObjectType_possibleTypes: string[] = ['ScoredProductObjectType']
    export const isScoredProductObjectType = (obj?: { __typename?: any } | null): obj is ScoredProductObjectType => {
      if (!obj?.__typename) throw new Error('__typename is missing in "isScoredProductObjectType"')
      return ScoredProductObjectType_possibleTypes.includes(obj.__typename)
    }
    


    const Query_possibleTypes: string[] = ['Query']
    export const isQuery = (obj?: { __typename?: any } | null): obj is Query => {
      if (!obj?.__typename) throw new Error('__typename is missing in "isQuery"')
      return Query_possibleTypes.includes(obj.__typename)
    }
    


    const UnsignedTransactionObjectUnionType_possibleTypes: string[] = ['UnsignedTransactionObjectType','ResponseErrorType']
    export const isUnsignedTransactionObjectUnionType = (obj?: { __typename?: any } | null): obj is UnsignedTransactionObjectUnionType => {
      if (!obj?.__typename) throw new Error('__typename is missing in "isUnsignedTransactionObjectUnionType"')
      return UnsignedTransactionObjectUnionType_possibleTypes.includes(obj.__typename)
    }
    


    const UnsignedTransactionObjectType_possibleTypes: string[] = ['UnsignedTransactionObjectType']
    export const isUnsignedTransactionObjectType = (obj?: { __typename?: any } | null): obj is UnsignedTransactionObjectType => {
      if (!obj?.__typename) throw new Error('__typename is missing in "isUnsignedTransactionObjectType"')
      return UnsignedTransactionObjectType_possibleTypes.includes(obj.__typename)
    }
    


    const Mutation_possibleTypes: string[] = ['Mutation']
    export const isMutation = (obj?: { __typename?: any } | null): obj is Mutation => {
      if (!obj?.__typename) throw new Error('__typename is missing in "isMutation"')
      return Mutation_possibleTypes.includes(obj.__typename)
    }
    

export const enumResponseErrorCodesEnum = {
   EMPTY_FIELD: 'EMPTY_FIELD' as const,
   UNEXPECTED_ERROR: 'UNEXPECTED_ERROR' as const,
   FOUND_MULTIPLE_DOCUMENTS: 'FOUND_MULTIPLE_DOCUMENTS' as const,
   DOCUMENT_NOT_FOUND: 'DOCUMENT_NOT_FOUND' as const,
   DOCUMENTS_NOT_FOUND: 'DOCUMENTS_NOT_FOUND' as const,
   VALIDATION_ERROR: 'VALIDATION_ERROR' as const,
   MONGO_ERROR: 'MONGO_ERROR' as const,
   REDIS_ERROR: 'REDIS_ERROR' as const
}

export const enumBlockchainEnum = {
   ETH: 'ETH' as const,
   BNB: 'BNB' as const
}

export const enumDefiEnum = {
   COMPOUND: 'COMPOUND' as const,
   ALPHAHOMORAV2: 'ALPHAHOMORAV2' as const,
   SUSHISWAP: 'SUSHISWAP' as const,
   UNISWAPV2: 'UNISWAPV2' as const,
   UNISWAPV3: 'UNISWAPV3' as const,
   PANCAKESWAP: 'PANCAKESWAP' as const,
   TOPCORN: 'TOPCORN' as const,
   ONEINCH: 'ONEINCH' as const
}

export const enumInvestStrategyEnum = {
   LOW: 'LOW' as const,
   MEDIUM: 'MEDIUM' as const,
   HIGH: 'HIGH' as const
}
