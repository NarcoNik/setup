import {
    DockerComposeEnvironment,
    StartedDockerComposeEnvironment,
    Wait,
} from 'testcontainers'

export const MONGO_COMPOSE_NAME = 'mongo-test-boilerplate-1'
export const REDIS_COMPOSE_NAME = 'redis-test-boilerplate-1'
export const RABBITMQ_COMPOSE_NAME = 'rabbitmq-test-boilerplate-1'
export const LOCAL_NODE_COMPOSE_NAME = 'hardhat-node-test-boilerplate-1'
export const MONGO_CONTAINER_NAME = 'nestjs-boilerplate-mongo-test'
export const LOCAL_NODE_CONTAINER_NAME = 'nestjs-boilerplate-hardhat-node-test'

/**
 * Функция создания и запуска докер контейнеров для тестов
 */
export const createDockerComposeEnvironment = async (): Promise<StartedDockerComposeEnvironment> => {
    const composeFilePath = './'
    const composeFile = 'docker-compose-test.yml'
    return await new DockerComposeEnvironment(composeFilePath, composeFile)
        .withEnvironmentFile('./.env.test')
        .withBuild()
        .withWaitStrategy(MONGO_COMPOSE_NAME, Wait.forLogMessage('Waiting for connections'))
        .withWaitStrategy(REDIS_COMPOSE_NAME, Wait.forLogMessage('Ready to accept connections'))
        .withWaitStrategy(RABBITMQ_COMPOSE_NAME, Wait.forLogMessage('Server startup complete'))
        .withWaitStrategy(LOCAL_NODE_COMPOSE_NAME, Wait.forLogMessage(
            `RPC Listening on 0.0.0.0:${process.env.HARDHAT_NODE_FORKING_NODE_PORT}`
        ))
        .up([MONGO_COMPOSE_NAME, REDIS_COMPOSE_NAME, RABBITMQ_COMPOSE_NAME, LOCAL_NODE_COMPOSE_NAME])
}

export const configureStartedDockerContainers = async (
    environment: StartedDockerComposeEnvironment
): Promise<void> => {
    const mongoContainer = environment.getContainer(MONGO_CONTAINER_NAME)
    const { output: mongoOutput, exitCode: mongoExitCode } = await mongoContainer.exec([
        'mongosh',
        '--port',
        '27018',
        '--eval',
        'let r={_id:"rs0",members:[{"_id":0,"host":"127.0.0.1:27018","priority":1}]};rs.initiate(r);',
    ])
    if (mongoExitCode !== 0) {
        throw new Error(`
            MONGODB EXEC ERROR:\n\n
            ExitCode: ${mongoExitCode}\n\n
            =============================\n
            Output message: ${mongoOutput}\n\n
            =============================\n
        `)
    }

    // TODO включить при необходимости
    // const localNodeContainer = environment.getContainer(LOCAL_NODE_CONTAINER_NAME)
    // const {
    //     output: approveContractsOutput,
    //     exitCode: approveContractsExitCode,
    // } = await localNodeContainer.exec(['npx', 'hardhat', 'approve-contracts-ganache'])
    // if (approveContractsExitCode !== 0) {
    //     throw new Error(`
    //         LOCAL NODE APPROVE CONTRACTS EXEC ERROR:\n\n
    //         ExitCode: ${approveContractsExitCode}\n\n
    //         =============================\n
    //         Output message: ${approveContractsOutput}\n\n
    //         =============================\n
    //     `)
    // }
    //
    // const {
    //     output: approveLiquidityOutput,
    //     exitCode: approveLiquidityExitCode,
    // } = await localNodeContainer.exec(['npx', 'hardhat', 'approve-liquidity-for-pool-ganache'])
    // if (approveLiquidityExitCode !== 0) {
    //     throw new Error(`
    //         LOCAL NODE APPROVE LIQUIDITY EXEC ERROR:\n\n
    //         ExitCode: ${approveLiquidityExitCode}\n\n
    //         =============================\n
    //         Output message: ${approveLiquidityOutput}\n\n
    //         =============================\n
    //     `)
    // }
    //
    // const {
    //     output: mintTokensOutput,
    //     exitCode: mintTokensExitCode,
    // } = await localNodeContainer.exec(['npx', 'hardhat', 'mint-tokens-ganache'])
    // if (mintTokensExitCode !== 0) {
    //     throw new Error(`
    //         LOCAL NODE MINT TOKENS EXEC ERROR:\n\n
    //         ExitCode: ${mintTokensExitCode}\n\n
    //         =============================\n
    //         Output message: ${mintTokensOutput}\n\n
    //         =============================\n
    //     `)
    // }
}