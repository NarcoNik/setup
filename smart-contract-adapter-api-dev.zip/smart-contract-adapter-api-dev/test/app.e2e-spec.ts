import { INestApplication } from '@nestjs/common'
import { Test, TestingModule } from '@nestjs/testing'
import { GraphQLClient } from 'graphql-request'
import { AppModule } from '../src/app.module'
import * as pactum from 'pactum'
import {
    configureStartedDockerContainers,
    createDockerComposeEnvironment,
} from './helpers'
import { AllExceptionsFilter } from '../src/all-exceptions.filter'

describe('e2e tests', () => {
    /** Установка времени работы тестов */
    // eslint-disable-next-line @typescript-eslint/no-magic-numbers
    jest.setTimeout(5 * 60 * 1000)

    let app: INestApplication
    let url: string
    let environment: Awaited<ReturnType<typeof createDockerComposeEnvironment>>

    GraphQLClient.prototype.request = jest.fn()

    beforeAll(async () => {
        environment = await createDockerComposeEnvironment()
        await configureStartedDockerContainers(environment)

        const moduleFixture: TestingModule = await Test
        .createTestingModule({ imports: [AppModule] })
        .compile()

        app = moduleFixture.createNestApplication()
        app.useGlobalFilters(new AllExceptionsFilter())
        await app.listen(0)

        url = await app.getUrl()
        pactum.request.setBaseUrl(url.replace('[::1]', 'localhost'))
    })

    afterAll(async () => {
        await app.close()
        await environment.down({
            removeVolumes: true,
        })
    })

    describe('TEST Scored Products', () => {
        describe('createScoredProduct method', () => {
            beforeAll(async () => {
                console.log('1')
            })

            // it('SUCCESS CASE', createScoredProductSuccessCase)
        })
    })
})
